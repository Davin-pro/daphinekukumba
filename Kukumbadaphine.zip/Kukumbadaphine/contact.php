<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$sent = false;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $subject = trim((string) ($_POST['subject'] ?? ''));
    $message = trim((string) ($_POST['message'] ?? ''));
    if ($name === '' || ($length = utf8_length($name)) === null || $length > 120) $errors[] = 'Please enter your name.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $errors[] = 'Please enter a valid email address.';
    if ($subject === '' || ($length = utf8_length($subject)) === null || $length > 190) $errors[] = 'Please enter a subject.';
    if ($message === '' || ($length = utf8_length($message)) === null || $length > 5000) $errors[] = 'Please enter a message (up to 5,000 characters).';
    if (!$errors) {
        $statement = $pdo->prepare('INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)');
        $statement->execute([$name, $email, $subject, $message]);
        $sent = true;
    }
}
$pageTitle = 'Contact | ' . ($profile['name'] ?? 'Kukumba Daphine');
require __DIR__ . '/includes/header.php';
?>
<section class="page-hero"><p class="eyebrow">GET IN TOUCH</p><h1>Let's talk<span>.</span></h1><p>Have a project, question or opportunity? Send a note and I'll get back to you.</p></section>
<section class="section contact-page-grid"><div class="contact-details"><h2>Contact information</h2><p><?= e($profile['location'] ?? 'Namagoma, Wakiso, Uganda') ?></p><?php if ($profile['email'] ?? ''): ?><a href="mailto:<?= e($profile['email']) ?>"><?= e($profile['email']) ?></a><?php endif; ?><?php if ($profile['phone'] ?? ''): ?><a href="tel:<?= e($profile['phone']) ?>"><?= e($profile['phone']) ?></a><a class="text-link" target="_blank" rel="noopener noreferrer" href="https://wa.me/<?= preg_replace('/\D+/', '', $profile['phone']) ?>">Message on WhatsApp ↗</a><?php endif; ?></div>
<form class="contact-form" method="post" action="contact.php"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><?php if ($sent): ?><div class="notice success">Thanks for reaching out. Your message has been received.</div><?php endif; ?><?php foreach ($errors as $error): ?><div class="notice error"><?= e($error) ?></div><?php endforeach; ?><div class="form-row"><label>Your name<input name="name" required maxlength="120" value="<?= e($_POST['name'] ?? '') ?>"></label><label>Email address<input name="email" type="email" required maxlength="190" value="<?= e($_POST['email'] ?? '') ?>"></label></div><label>Subject<input name="subject" required maxlength="190" value="<?= e($_POST['subject'] ?? '') ?>"></label><label>Message<textarea name="message" rows="6" required maxlength="5000"><?= e($_POST['message'] ?? '') ?></textarea></label><button class="button" type="submit">Send message <span>↗</span></button></form></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
