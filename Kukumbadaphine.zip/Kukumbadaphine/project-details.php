<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$statement = $pdo->prepare('SELECT * FROM projects WHERE id = ?');
$statement->execute([(int) ($_GET['id'] ?? 0)]);
$project = $statement->fetch();
if (!$project) { http_response_code(404); $pageTitle = 'Project not found'; require __DIR__ . '/includes/header.php'; echo '<section class="page-hero"><h1>Project not found.</h1><a class="text-link" href="projects.php">Back to projects</a></section>'; require __DIR__ . '/includes/footer.php'; exit; }
$pageTitle = $project['title'] . ' | ' . ($profile['name'] ?? 'Kukumba Daphine');
require __DIR__ . '/includes/header.php';
?>
<article class="article-page"><p class="eyebrow"><?= e($project['category']) ?> · PROJECT</p><h1><?= e($project['title']) ?></h1><p class="article-lead"><?= e($project['description']) ?></p><?php if ($project['image']): ?><img class="article-cover" src="<?= e($project['image']) ?>" alt="<?= e($project['title']) ?>"><?php endif; ?><div class="article-body"><?= nl2br(e($project['details'])) ?></div><p class="detail-label">TECHNOLOGIES</p><p><?= e($project['technologies']) ?></p><div class="hero-actions"><?php if ($project['live_url']): ?><a class="button" href="<?= e($project['live_url']) ?>" target="_blank" rel="noopener noreferrer">Visit project ↗</a><?php endif; ?><?php if ($project['github_url']): ?><a class="button button-outline" href="<?= e($project['github_url']) ?>" target="_blank" rel="noopener noreferrer">Source code ↗</a><?php endif; ?></div></article>
<?php require __DIR__ . '/includes/footer.php'; ?>
