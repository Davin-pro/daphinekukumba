<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$posts = $pdo->query("SELECT p.*, c.name AS category_name FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id WHERE p.status = 'published' ORDER BY p.published_at DESC")->fetchAll();
$pageTitle = 'Journal | ' . ($profile['name'] ?? 'Kukumba Daphine');
$activePage = 'blog';
require __DIR__ . '/includes/header.php';
?>
<section class="page-hero"><p class="eyebrow">IDEAS & INSIGHTS</p><h1>The journal<span>.</span></h1><p>Notes on technology, development, design and the work of learning.</p></section>
<section class="section"><div class="journal-grid"><?php foreach ($posts as $post): ?><a class="journal-card reveal" href="blog-details.php?slug=<?= urlencode($post['slug']) ?>"><?php if ($post['featured_image']): ?><img src="<?= e($post['featured_image']) ?>" alt=""><?php else: ?><div class="journal-placeholder">KD<span> JOURNAL</span></div><?php endif; ?><div class="journal-content"><span class="detail-label"><?= e($post['category_name'] ?? 'ARTICLE') ?> · <?= e($post['published_at'] ? date('M j, Y', strtotime($post['published_at'])) : '') ?></span><h3><?= e($post['title']) ?></h3><p><?= e($post['excerpt']) ?></p><span class="text-link">Read article ↗</span></div></a><?php endforeach; ?><?php if (!$posts): ?><p class="empty-state">Articles will be published here soon.</p><?php endif; ?></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
