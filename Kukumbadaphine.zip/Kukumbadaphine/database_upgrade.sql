USE kukumba_portfolio;

ALTER TABLE site_settings MODIFY setting_value MEDIUMTEXT NOT NULL;

CREATE TABLE IF NOT EXISTS timeline_events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    period VARCHAR(80) NOT NULL,
    title VARCHAR(190) NOT NULL,
    role VARCHAR(190) NOT NULL DEFAULT '',
    description TEXT NOT NULL,
    technologies VARCHAR(500) NOT NULL DEFAULT '',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS innovation_interests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    description VARCHAR(500) NOT NULL DEFAULT '',
    icon VARCHAR(40) NOT NULL DEFAULT '✦',
    sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS terminal_commands (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    command VARCHAR(40) NOT NULL UNIQUE,
    description VARCHAR(190) NOT NULL,
    output TEXT NOT NULL DEFAULT ''
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_rate_limits (
    client_hash CHAR(64) NOT NULL,
    window_start BIGINT UNSIGNED NOT NULL,
    request_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (client_hash, window_start),
    INDEX idx_rate_window (window_start)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    model VARCHAR(100) NOT NULL,
    prompt_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    completion_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    success TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ai_usage_created (created_at, success)
) ENGINE=InnoDB;

INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES
('ai_enabled', '0'),
('ai_knowledge', '');

INSERT IGNORE INTO terminal_commands (command, description, output) VALUES
('help', 'Show available commands', ''),
('about', 'Professional introduction', ''),
('skills', 'Technical skills', ''),
('projects', 'Development projects', ''),
('experience', 'Employment history', ''),
('education', 'Academic qualifications', ''),
('services', 'Professional services', ''),
('articles', 'Published articles', ''),
('contact', 'Contact information', ''),
('ai', 'Open Daphine AI', ''),
('clear', 'Clear the terminal', '');

INSERT IGNORE INTO innovation_interests (name, description, icon, sort_order) VALUES
('Artificial Intelligence', 'Exploring practical applications of AI.', '✦', 1),
('Cybersecurity', 'Learning about security and digital resilience.', '◈', 2),
('Full-stack Development', 'Building complete, data-driven web experiences.', '⌘', 3),
('Database Engineering', 'Designing reliable data systems and workflows.', '▤', 4),
('Cloud Technologies', 'Exploring modern cloud platforms and services.', '☁', 5),
('Systems Administration', 'Managing infrastructure and dependable systems.', '⌁', 6);
