<?php
require_once __DIR__ . '/includes/functions.php';

if ((int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0) {
    http_response_code(404);
    exit('Initial setup is already complete.');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
    if (!preg_match('/^[A-Za-z0-9._-]{3,80}$/', $username)) $errors[] = 'Use 3–80 letters, numbers, dots, underscores or hyphens for the username.';
    if (strlen($password) < 12) $errors[] = 'Use a password with at least 12 characters.';
    if ($password !== $confirmPassword) $errors[] = 'The password confirmation does not match.';

    if (!$errors) {
        $statement = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
        try {
            $statement->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int) $pdo->lastInsertId();
            $_SESSION['admin_username'] = $username;
            header('Location: admin/dashboard.php');
            exit;
        } catch (PDOException $exception) {
            if ($exception->getCode() !== '23000') throw $exception;
            $errors[] = 'An administrator was just created. Sign in instead.';
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Initial setup | Kukumba Daphine</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="admin-body"><main class="login-shell"><div class="login-card"><a class="brand" href="index.php"><span class="brand-mark">KD</span><span>Kukumba Daphine<small>Portfolio setup</small></span></a><p class="eyebrow">ONE-TIME SETUP</p><h1>Create your administrator</h1><p class="muted">Choose a unique username and a strong password of at least 12 characters.</p><?php foreach ($errors as $error): ?><div class="notice error"><?= e($error) ?></div><?php endforeach; ?><form class="admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Username<input name="username" required minlength="3" maxlength="80" autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label><label>Password<input type="password" name="password" required minlength="12" autocomplete="new-password"></label><label>Confirm password<input type="password" name="confirm_password" required minlength="12" autocomplete="new-password"></label><button class="button" type="submit">Create admin account</button></form></div></main></body></html>
