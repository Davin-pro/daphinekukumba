const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('.main-nav');

if (menuButton && navigation) {
    menuButton.addEventListener('click', () => {
        const expanded = menuButton.getAttribute('aria-expanded') === 'true';
        menuButton.setAttribute('aria-expanded', String(!expanded));
        navigation.classList.toggle('is-open', !expanded);
    });

    navigation.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            menuButton.setAttribute('aria-expanded', 'false');
            navigation.classList.remove('is-open');
        });
    });
}

const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach((element) => revealObserver.observe(element));

const animatedNameCharacters = [...document.querySelectorAll('.hero h1 .name-character')];
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

if (animatedNameCharacters.length > 0) {
    if (prefersReducedMotion.matches) {
        animatedNameCharacters.forEach((character) => character.classList.add('is-typed'));
    } else {
        let characterIndex = 0;
        const typeNextCharacter = () => {
            if (prefersReducedMotion.matches) {
                animatedNameCharacters.forEach((character) => character.classList.add('is-typed'));
                return;
            }

            if (characterIndex >= animatedNameCharacters.length) {
                window.setTimeout(() => {
                    animatedNameCharacters.forEach((character) => character.classList.remove('is-typed'));
                    characterIndex = 0;
                    window.setTimeout(typeNextCharacter, 180);
                }, 5000);
                return;
            }

            animatedNameCharacters[characterIndex].classList.add('is-typed');
            characterIndex += 1;
            window.setTimeout(typeNextCharacter, 95);
        };

        typeNextCharacter();
        prefersReducedMotion.addEventListener('change', (event) => {
            if (event.matches) animatedNameCharacters.forEach((character) => character.classList.add('is-typed'));
        });
    }
}

const assistantWidget = document.querySelector('#assistantWidget');
const assistantLauncher = document.querySelector('#assistantLauncher');
const assistantPanel = document.querySelector('#assistantPanel');
const assistantClose = document.querySelector('.assistant-close');
const assistantForm = document.querySelector('#assistantForm');
const assistantInput = document.querySelector('#assistantInput');
const assistantMessages = document.querySelector('#assistantMessages');
const assistantSuggestions = document.querySelector('#assistantSuggestions');
const assistantStatus = document.querySelector('#assistantStatus');
let conversation = [];

function openAssistant() {
    if (!assistantPanel || !assistantLauncher) return;
    assistantPanel.hidden = false;
    assistantPanel.setAttribute('aria-hidden', 'false');
    assistantLauncher.setAttribute('aria-expanded', 'true');
    if (assistantMessages && !assistantMessages.childElementCount) {
        appendAssistantMessage("Hello, I'm Daphine's professional digital assistant. Ask me about her background, skills, projects, education, services, or interests.", 'bot');
    }
    assistantInput?.focus();
}

function appendAssistantMessage(text, sender, className = '') {
    if (!assistantMessages) return null;
    const message = document.createElement('div');
    message.className = `assistant-message assistant-message-${sender}${className ? ` ${className}` : ''}`;
    const content = document.createElement('p');
    content.textContent = text;
    message.append(content);
    assistantMessages.append(message);
    assistantMessages.scrollTop = assistantMessages.scrollHeight;
    return message;
}

function closeAssistant() {
    if (!assistantPanel || !assistantLauncher) return;
    assistantPanel.hidden = true;
    assistantPanel.setAttribute('aria-hidden', 'true');
    assistantLauncher.setAttribute('aria-expanded', 'false');
    assistantLauncher.focus();
}

if (assistantLauncher && assistantPanel && assistantClose && assistantForm && assistantInput && assistantMessages && assistantWidget) {
    assistantLauncher.addEventListener('click', openAssistant);
    assistantClose.addEventListener('click', closeAssistant);
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !assistantPanel.hidden) closeAssistant();
    });

    const sendMessage = async (question) => {
        conversation.push({ role: 'user', content: question });
        const loading = appendAssistantMessage('Daphine AI is thinking', 'bot', 'assistant-typing');
        const submitButton = assistantForm.querySelector('button[type="submit"]');
        assistantInput.disabled = true;
        if (submitButton) submitButton.disabled = true;
        if (assistantStatus) assistantStatus.textContent = 'Connecting securely…';

        try {
            const response = await fetch(assistantWidget.dataset.endpoint || 'api/assistant.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': assistantWidget.dataset.csrf || '',
                },
                body: JSON.stringify({ messages: conversation.slice(-8) }),
                credentials: 'same-origin',
            });
            const result = await response.json();
            if (!response.ok || typeof result.answer !== 'string') {
                throw new Error(result.error || 'Daphine AI could not answer right now. Please try again later.');
            }
            conversation.push({ role: 'assistant', content: result.answer });
            loading?.remove();
            appendAssistantMessage(result.answer, 'bot');
            if (assistantStatus) assistantStatus.textContent = 'AI answers based on verified portfolio information.';
        } catch (error) {
            loading?.remove();
            conversation.pop();
            appendAssistantMessage(error instanceof Error ? error.message : 'A network error occurred. Please try again.', 'bot', 'assistant-error');
            if (assistantStatus) assistantStatus.textContent = 'Messages are not stored.';
        } finally {
            assistantInput.disabled = false;
            if (submitButton) submitButton.disabled = false;
            assistantInput.focus();
        }
    };

    assistantForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const question = assistantInput.value.trim();
        if (!question || assistantInput.disabled) return;
        appendAssistantMessage(question, 'user');
        assistantInput.value = '';
        void sendMessage(question);
    });

    assistantSuggestions?.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-question]');
        if (!button || assistantInput.disabled) return;
        assistantInput.value = button.dataset.question || '';
        assistantForm.requestSubmit();
    });
}

const terminal = document.querySelector('#developerTerminal');
const terminalForm = document.querySelector('#terminalForm');
const terminalInput = document.querySelector('#terminalInput');
const terminalOutput = document.querySelector('#terminalOutput');
const terminalDataElement = document.querySelector('#terminalData');

if (terminal && terminalForm && terminalInput && terminalOutput && terminalDataElement) {
    let data = {};
    try {
        data = JSON.parse(terminalDataElement.textContent || '{}');
    } catch (error) {
        console.error('The terminal portfolio data could not be loaded.', error);
    }
    const commands = Array.isArray(data.commands) ? data.commands : [];
    const history = [];
    let historyIndex = 0;

    const printLine = (text, type = 'output') => {
        const line = document.createElement('div');
        line.className = `terminal-line terminal-${type}`;
        terminalOutput.append(line);
        const content = String(text);
        if (type !== 'output' || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            line.textContent = content;
        } else {
            let index = 0;
            const step = () => {
                line.textContent = content.slice(0, index += 8);
                terminalOutput.scrollTop = terminalOutput.scrollHeight;
                if (index < content.length) window.requestAnimationFrame(step);
            };
            step();
        }
        terminalOutput.scrollTop = terminalOutput.scrollHeight;
        while (terminalOutput.childElementCount > 65) terminalOutput.firstElementChild?.remove();
    };

    const listText = (items, render, emptyText) => Array.isArray(items) && items.length
        ? items.map(render).join('\n')
        : emptyText;

    const executeCommand = (input) => {
        const [name, ...args] = input.trim().split(/\s+/);
        const command = name.toLowerCase();
        printLine(`visitor@daphine:~$ ${input}`, 'prompt');
        if (command === 'clear') {
            terminalOutput.replaceChildren();
            return;
        }
        if (command === 'ai') {
            printLine('Opening Daphine AI…');
            openAssistant();
            return;
        }
        let output = '';
        switch (command) {
            case 'help':
                output = ['Available commands:', ...commands.map((item) => `  ${item.command.padEnd(14)} ${item.description}`), 'Use ↑ and ↓ to browse command history.'].join('\n');
                break;
            case 'about':
                output = `${data.profile?.name || 'Daphine'} · ${data.profile?.title || 'Computer Engineer'}\n${data.profile?.introduction || 'No introduction has been added yet.'}\n${data.profile?.biography || ''}`.trim();
                break;
            case 'skills':
                output = listText(data.skills, (skill) => `• ${skill}`, 'No skills have been added yet.');
                break;
            case 'projects':
                output = listText(data.projects, (project) => `• ${project.title}${project.technologies ? ` — ${project.technologies}` : ''}\n  ${project.description}`, 'No projects have been published yet.');
                break;
            case 'experience':
                output = listText(data.experience, (item) => `• ${item.role} — ${item.organization}${item.start_date || item.end_date ? ` (${item.start_date || ''}${item.start_date && item.end_date ? ' – ' : ''}${item.end_date || ''})` : ''}\n  ${item.details}`, 'No employment history has been published.');
                break;
            case 'education':
                output = listText(data.education, (item) => `• ${item.qualification} — ${item.institution}${item.start_date || item.end_date ? ` (${item.start_date || ''}${item.start_date && item.end_date ? ' – ' : ''}${item.end_date || ''})` : ''}\n  ${item.details}`, 'No academic qualifications have been published.');
                break;
            case 'services':
                output = listText(data.services, (item) => `• ${item.name}: ${item.description}`, 'No services have been published.');
                break;
            case 'articles':
                output = listText(data.articles, (item) => `• ${item.title} — ${item.excerpt}`, 'No articles have been published yet.');
                break;
            case 'contact': {
                const contact = data.profile || {};
                output = [`Location: ${contact.location || 'Not provided'}`, `Email: ${contact.email || 'Not provided'}`, `Phone: ${contact.phone || 'Not provided'}`, 'Use the Contact page to start a conversation.'].join('\n');
                break;
            }
            default: {
                const custom = commands.find((item) => item.command === command);
                output = custom?.output || (args.length ? `Command "${command}" does not accept arguments.` : `Unknown command: ${command}. Type "help" to see available commands.`);
            }
        }
        printLine(output || 'No information available.');
    };

    terminalForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const command = terminalInput.value.trim();
        if (!command) return;
        history.push(command);
        historyIndex = history.length;
        terminalInput.value = '';
        executeCommand(command);
    });

    terminalInput.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            historyIndex = Math.max(0, historyIndex - 1);
            terminalInput.value = history[historyIndex] || '';
        } else if (event.key === 'ArrowDown') {
            event.preventDefault();
            historyIndex = Math.min(history.length, historyIndex + 1);
            terminalInput.value = history[historyIndex] || '';
        }
    });

    terminal.querySelectorAll('[data-terminal-command]').forEach((button) => {
        button.addEventListener('click', () => {
            const command = button.dataset.terminalCommand || '';
            terminalInput.value = command;
            terminalForm.requestSubmit();
            terminalInput.focus();
        });
    });

    terminal.addEventListener('click', (event) => {
        if (!event.target.closest('a, button')) terminalInput.focus();
    });
}
