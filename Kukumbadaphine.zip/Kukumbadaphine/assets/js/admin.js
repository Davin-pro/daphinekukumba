const editTypes = {
    service_delete: 'service',
    project_delete: 'project',
    post_delete: 'post',
    experience_delete: 'experience',
    education_delete: 'education',
};

const sectionLabels = {
    experience: 'Experience',
    education: 'Education',
};
const sidebarNavigation = document.querySelector('.admin-sidebar nav');

Object.entries(sectionLabels).forEach(([id, label]) => {
    if (!sidebarNavigation || sidebarNavigation.querySelector(`a[href="#${id}"]`)) return;
    const section = document.getElementById(id);
    if (!section) return;
    const link = document.createElement('a');
    link.href = `#${id}`;
    link.textContent = label;
    sidebarNavigation.append(link);
});

const heroPreview = document.querySelector('#heroPreview');
const heroImageInput = document.querySelector('#heroImageInput');
const heroPositionX = document.querySelector('#heroPositionX');
const heroPositionY = document.querySelector('#heroPositionY');
const heroPositionXOutput = document.querySelector('#heroPositionXOutput');
const heroPositionYOutput = document.querySelector('#heroPositionYOutput');
const portraitPreview = document.querySelector('#portraitPreview');
const portraitPreviewImage = document.querySelector('#portraitPreviewImage');
const portraitImageInput = document.querySelector('#portraitImageInput');
const portraitFit = document.querySelector('#portraitFit');
const portraitPositionX = document.querySelector('#portraitPositionX');
const portraitPositionY = document.querySelector('#portraitPositionY');
const portraitPositionXOutput = document.querySelector('#portraitPositionXOutput');
const portraitPositionYOutput = document.querySelector('#portraitPositionYOutput');
let portraitPreviewUrl = null;

function updateHeroPreviewPosition() {
    if (!heroPreview || !heroPositionX || !heroPositionY) return;
    heroPreview.style.backgroundPosition = `${heroPositionX.value}% ${heroPositionY.value}%`;
    if (heroPositionXOutput) heroPositionXOutput.value = `${heroPositionX.value}%`;
    if (heroPositionYOutput) heroPositionYOutput.value = `${heroPositionY.value}%`;
}

if (heroImageInput && heroPreview) {
    heroImageInput.addEventListener('change', () => {
        const [file] = heroImageInput.files || [];
        if (!file) return;
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
            heroImageInput.value = '';
            window.alert('Choose a JPEG, PNG or WebP image.');
            return;
        }
        if (file.size > 8 * 1024 * 1024) {
            heroImageInput.value = '';
            window.alert('The hero background image must be 8 MB or smaller.');
            return;
        }
        const reader = new FileReader();
        reader.addEventListener('load', () => {
            if (typeof reader.result === 'string') {
                heroPreview.style.backgroundImage = `linear-gradient(rgba(7,20,33,.2),rgba(7,20,33,.2)),url("${reader.result}")`;
            }
        });
        reader.readAsDataURL(file);
    });
}

heroPositionX?.addEventListener('input', updateHeroPreviewPosition);
heroPositionY?.addEventListener('input', updateHeroPreviewPosition);

function updatePortraitPreview() {
    if (!portraitPreviewImage || !portraitPositionX || !portraitPositionY || !portraitFit) return;
    portraitPreviewImage.style.objectPosition = `${portraitPositionX.value}% ${portraitPositionY.value}%`;
    portraitPreviewImage.style.objectFit = portraitFit.value;
    if (portraitPositionXOutput) portraitPositionXOutput.value = `${portraitPositionX.value}%`;
    if (portraitPositionYOutput) portraitPositionYOutput.value = `${portraitPositionY.value}%`;
}

if (portraitImageInput && portraitPreview && portraitPreviewImage) {
    portraitImageInput.addEventListener('change', () => {
        const [file] = portraitImageInput.files || [];
        if (!file) return;
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
            portraitImageInput.value = '';
            window.alert('Choose a JPG, PNG or WebP portrait.');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            portraitImageInput.value = '';
            window.alert('The portrait image must be 5 MB or smaller.');
            return;
        }
        if (portraitPreviewUrl) URL.revokeObjectURL(portraitPreviewUrl);
        portraitPreviewUrl = URL.createObjectURL(file);
        portraitPreviewImage.src = portraitPreviewUrl;
        portraitPreviewImage.hidden = false;
        portraitPreviewImage.alt = 'New portrait preview';
        updatePortraitPreview();
    });
}

portraitPositionX?.addEventListener('input', updatePortraitPreview);
portraitPositionY?.addEventListener('input', updatePortraitPreview);
portraitFit?.addEventListener('change', updatePortraitPreview);

document.querySelectorAll('.admin-list article').forEach((row) => {
    const deleteForm = row.querySelector('form');
    const action = deleteForm?.querySelector('input[name="action"]')?.value;
    const id = deleteForm?.querySelector('input[name="id"]')?.value;
    const type = editTypes[action];

    if (!type || !id) return;

    const link = document.createElement('a');
    link.className = 'small-action';
    link.href = `edit.php?type=${encodeURIComponent(type)}&id=${encodeURIComponent(id)}`;
    link.textContent = 'Edit';
    deleteForm.before(link);
});
