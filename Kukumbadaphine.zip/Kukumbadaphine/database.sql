CREATE DATABASE IF NOT EXISTS kukumba_portfolio
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE kukumba_portfolio;

CREATE TABLE IF NOT EXISTS admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile (
    id TINYINT UNSIGNED PRIMARY KEY,
    name VARCHAR(120) NOT NULL DEFAULT 'Kukumba Daphine',
    title VARCHAR(180) NOT NULL DEFAULT 'Computer Engineer',
    hero_title VARCHAR(180) NOT NULL DEFAULT 'Computer Engineer & Full-Stack Developer',
    hero_intro TEXT NOT NULL,
    about_heading VARCHAR(255) NOT NULL,
    biography TEXT NOT NULL,
    about_more TEXT NOT NULL,
    location VARCHAR(180) NOT NULL,
    email VARCHAR(190) NOT NULL DEFAULT '',
    phone VARCHAR(50) NOT NULL DEFAULT '',
    languages VARCHAR(255) NOT NULL DEFAULT 'English',
    experience_stat VARCHAR(80) NOT NULL DEFAULT 'IT',
    projects_stat VARCHAR(80) NOT NULL DEFAULT 'Web',
    skills_stat VARCHAR(80) NOT NULL DEFAULT 'Full-stack',
    roles_stat VARCHAR(100) NOT NULL DEFAULT 'Multi-disciplinary',
    portrait VARCHAR(255) DEFAULT NULL,
    portrait_position_x VARCHAR(5) NOT NULL DEFAULT '50%',
    portrait_position_y VARCHAR(5) NOT NULL DEFAULT '50%',
    portrait_fit VARCHAR(10) NOT NULL DEFAULT 'contain',
    hero_image VARCHAR(255) NOT NULL DEFAULT 'assets/images/canadian-rockies.jpg',
    hero_position_x VARCHAR(5) NOT NULL DEFAULT '50%',
    hero_position_y VARCHAR(5) NOT NULL DEFAULT '50%',
    cv_file VARCHAR(255) DEFAULT NULL,
    seo_description VARCHAR(320) NOT NULL DEFAULT '',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS services (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(40) NOT NULL DEFAULT '*',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS projects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(210) NOT NULL UNIQUE,
    category VARCHAR(100) NOT NULL DEFAULT '',
    description TEXT NOT NULL,
    details MEDIUMTEXT NOT NULL,
    technologies VARCHAR(500) NOT NULL DEFAULT '',
    image VARCHAR(255) DEFAULT NULL,
    live_url VARCHAR(500) NOT NULL DEFAULT '',
    github_url VARCHAR(500) NOT NULL DEFAULT '',
    featured TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_projects_featured (featured, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS skills (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS education (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    institution VARCHAR(190) NOT NULL,
    qualification VARCHAR(190) NOT NULL,
    details TEXT NOT NULL,
    start_date VARCHAR(20) DEFAULT NULL,
    end_date VARCHAR(20) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS experience (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization VARCHAR(190) NOT NULL,
    role VARCHAR(190) NOT NULL,
    details TEXT NOT NULL,
    start_date VARCHAR(20) DEFAULT NULL,
    end_date VARCHAR(20) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS blog_categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS blog_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED DEFAULT NULL,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(210) NOT NULL UNIQUE,
    excerpt TEXT NOT NULL,
    body MEDIUMTEXT NOT NULL,
    featured_image VARCHAR(255) DEFAULT NULL,
    status ENUM('draft', 'published') NOT NULL DEFAULT 'draft',
    published_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_posts_category FOREIGN KEY (category_id) REFERENCES blog_categories(id) ON DELETE SET NULL,
    INDEX idx_posts_status_published (status, published_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contact_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL,
    subject VARCHAR(190) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_messages_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS social_links (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    label VARCHAR(60) NOT NULL,
    url VARCHAR(500) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS site_settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value MEDIUMTEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS timeline_events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    period VARCHAR(80) NOT NULL,
    title VARCHAR(190) NOT NULL,
    role VARCHAR(190) NOT NULL DEFAULT '',
    description TEXT NOT NULL,
    technologies VARCHAR(500) NOT NULL DEFAULT '',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS innovation_interests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    description VARCHAR(500) NOT NULL DEFAULT '',
    icon VARCHAR(40) NOT NULL DEFAULT '✦',
    sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS terminal_commands (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    command VARCHAR(40) NOT NULL UNIQUE,
    description VARCHAR(190) NOT NULL,
    output TEXT NOT NULL DEFAULT ''
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_rate_limits (
    client_hash CHAR(64) NOT NULL,
    window_start BIGINT UNSIGNED NOT NULL,
    request_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (client_hash, window_start),
    INDEX idx_rate_window (window_start)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    model VARCHAR(100) NOT NULL,
    prompt_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    completion_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    success TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ai_usage_created (created_at, success)
) ENGINE=InnoDB;

INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES
('ai_enabled', '0'),
('ai_knowledge', '');

INSERT IGNORE INTO terminal_commands (command, description, output) VALUES
('help', 'Show available commands', ''),
('about', 'Professional introduction', ''),
('skills', 'Technical skills', ''),
('projects', 'Development projects', ''),
('experience', 'Employment history', ''),
('education', 'Academic qualifications', ''),
('services', 'Professional services', ''),
('articles', 'Published articles', ''),
('contact', 'Contact information', ''),
('ai', 'Open Daphine AI', ''),
('clear', 'Clear the terminal', '');

INSERT IGNORE INTO innovation_interests (name, description, icon, sort_order) VALUES
('Artificial Intelligence', 'Exploring practical applications of AI.', '✦', 1),
('Cybersecurity', 'Learning about security and digital resilience.', '◈', 2),
('Full-stack Development', 'Building complete, data-driven web experiences.', '⌘', 3),
('Database Engineering', 'Designing reliable data systems and workflows.', '▤', 4),
('Cloud Technologies', 'Exploring modern cloud platforms and services.', '☁', 5),
('Systems Administration', 'Managing infrastructure and dependable systems.', '⌁', 6);

INSERT IGNORE INTO profile
(id, name, title, hero_title, hero_intro, about_heading, biography, about_more, location, email, phone, languages, hero_image, seo_description)
VALUES
(1, 'Kukumba Daphine', 'Computer Engineer', 'Computer Engineer & Full-Stack Developer',
 'I build innovative digital solutions, develop powerful web applications and transform ideas into practical technology solutions.',
 'Building Technology Solutions That Make an Impact.',
 'I am a technology professional with experience in software development, information technology, networking, systems administration, graphics design, digital marketing and ICT education.',
 'I specialize in developing practical technology solutions, designing digital experiences, managing IT infrastructure and helping organizations leverage technology to improve their operations.',
 'Namagoma, Wakiso, Uganda', '', '', 'English', 'assets/images/canadian-rockies.jpg', 'Computer Engineer, Full-Stack Developer and IT Specialist based in Namagoma, Wakiso, Uganda.');

INSERT INTO services (name, description, icon, sort_order)
SELECT 'Web Development', 'Custom websites, web applications, PHP systems and database solutions.', '</>', 1
WHERE NOT EXISTS (SELECT 1 FROM services);
INSERT INTO services (name, description, icon, sort_order)
SELECT 'IT Support & Systems Administration', 'Technical support, networking, troubleshooting and IT infrastructure management.', 'IT', 2
WHERE (SELECT COUNT(*) FROM services) = 1;
INSERT INTO services (name, description, icon, sort_order)
SELECT 'Graphics & Digital Design', 'Branding, visual communication, marketing graphics and digital content.', 'GD', 3
WHERE (SELECT COUNT(*) FROM services) = 2;
INSERT INTO services (name, description, icon, sort_order)
SELECT 'Database & Software Solutions', 'Database architecture, management systems and business automation.', 'DB', 4
WHERE (SELECT COUNT(*) FROM services) = 3;

INSERT IGNORE INTO skills (name, sort_order) VALUES
('PHP & MySQL', 1), ('Full-Stack Development', 2), ('Networking', 3),
('Systems Administration', 4), ('WordPress', 5), ('Cybersecurity', 6),
('Graphics Design', 7), ('ICT Education', 8), ('Digital Marketing', 9);

INSERT IGNORE INTO blog_categories (name, slug) VALUES
('Technology', 'technology'), ('Development', 'development'),
('IT Insights', 'it-insights'), ('Cybersecurity', 'cybersecurity');
