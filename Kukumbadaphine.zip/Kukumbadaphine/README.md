# Kukumba Daphine Portfolio

A responsive PHP 8 and MySQL portfolio for XAMPP and standard PHP hosting. Public content is loaded from MySQL; use the one-time setup page to create the first administrator and the admin dashboard to manage the portfolio.

## Local XAMPP installation

1. Copy the project folder into XAMPP's `htdocs` directory (for this workspace: `C:\xampp3\htdocs\Kukumbadaphine`).
2. Start Apache and MySQL in the XAMPP Control Panel.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`, import `database.sql`, and confirm the `kukumba_portfolio` database was created.
4. If your local MySQL credentials differ from the defaults (`root` with an empty password), set `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS` in the PHP/Apache environment before starting Apache. The database connection is in `config/database.php`.
5. Visit `http://localhost/Kukumbadaphine/setup.php` once to create an administrator. The setup page disables itself after the first admin is created.
6. Sign in at `http://localhost/Kukumbadaphine/admin/login.php` and manage content at `http://localhost/Kukumbadaphine/admin/dashboard.php`.
7. Remove or restrict `setup.php` after setup as an extra deployment precaution. Keep the `uploads` directory writable by PHP; uploaded images and the CV are validated and stored there.

The hero uses the bundled Lake Louise, Canadian Rockies photograph at `assets/images/canadian-rockies.jpg` by default. The panorama is by [Chensiyuan](https://commons.wikimedia.org/wiki/File:1_lake_louise_pano_2019.jpg), licensed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); it is resized for the site, and attribution is shown in the footer. From **Dashboard → Profile & media**, preview a replacement hero image, adjust its horizontal/vertical position, then save. Use **Restore default scenic background** to revert. Existing installations must add the new `hero_position_x` and `hero_position_y` profile columns with:

```sql
ALTER TABLE profile
    ADD COLUMN hero_position_x VARCHAR(5) NOT NULL DEFAULT '50%',
    ADD COLUMN hero_position_y VARCHAR(5) NOT NULL DEFAULT '50%';
UPDATE profile
SET hero_image = 'assets/images/canadian-rockies.jpg'
WHERE hero_image IS NULL OR hero_image = '';
```

Existing installations also need portrait framing fields for the dashboard's crop controls:

```sql
ALTER TABLE profile
    ADD COLUMN portrait_position_x VARCHAR(5) NOT NULL DEFAULT '50%',
    ADD COLUMN portrait_position_y VARCHAR(5) NOT NULL DEFAULT '50%',
    ADD COLUMN portrait_fit VARCHAR(10) NOT NULL DEFAULT 'contain';
```

In **Dashboard → Profile & media → Hero portrait**, upload JPG, PNG or WebP up to 5 MB. The dashboard previews the portrait, offers full-image fit or fill-and-crop, and saves horizontal/vertical positioning for the homepage.

The homepage includes **DAPHINE AI**, an OpenAI-powered assistant grounded in the saved portfolio information, plus a working developer terminal, professional journey timeline, and editable Innovation Radar. The assistant uses a server-side PHP endpoint; messages are sent to OpenAI to generate answers but are not stored by this site. Only model, request success, and token counts are kept for dashboard usage statistics. Requests are limited to 12 per IP address per hour.

## Upgrade an existing installation

Back up the database, then import `database_upgrade.sql` into the existing `kukumba_portfolio` database. It creates the tables and default terminal commands and interests required by the new features; it does not overwrite existing portfolio content. Fresh installations should import the updated `database.sql` instead.

To paste an API key in the admin dashboard, first set `APP_ENCRYPTION_KEY` in the PHP/Apache environment. Generate a random 32-byte key locally with:

```powershell
php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
```

Set the generated output as `APP_ENCRYPTION_KEY` in the server environment and restart Apache. Keep it private and back it up securely; without it, an API key saved in the dashboard cannot be decrypted. The dashboard encrypts the pasted OpenAI key with AES-256-GCM before saving it in MySQL. Alternatively, set `OPENAI_API_KEY` in the server environment; that environment key takes precedence over the dashboard key.

Optional variables in the PHP/Apache environment:

- `OPENAI_API_KEY` — optional secret key override; never put it in website files or browser code.
- `APP_ENCRYPTION_KEY` — base64-encoded random 32-byte key required to save a key in the dashboard.
- `OPENAI_MODEL` — optional model name (defaults to `gpt-4o-mini`).
- `OPENAI_MAX_OUTPUT_TOKENS` — optional answer limit from 64 to 1,200 (defaults to `400`).
- `APP_RATE_LIMIT_SECRET` — optional random secret used to hash visitor IPs for rate limiting; if omitted, the API key is used.

The server must allow outbound HTTPS requests and PHP `allow_url_fopen` for the OpenAI API call. The AI assistant is off by default. After setting the key, sign in to the dashboard, add accurate extra knowledge under **Daphine AI**, and enable it. The system prompt instructs the model not to make up missing facts, but review the knowledge and test answers before promoting the site.

Manage verified timeline entries, terminal commands, and Innovation Radar interests in their respective dashboard sections. Built-in terminal commands always use live portfolio data and cannot be removed; custom commands display the plain-text output supplied in the dashboard.

## Shared hosting

Create a MySQL database and user in your hosting panel, import `database.sql` (or use `database_upgrade.sql` for an existing installation), and configure the four database environment variables above. Configure the OpenAI environment variables before enabling DAPHINE AI. Upload the project into the site's document root and ensure `uploads/` is writable by the PHP process. Use HTTPS for the whole site and admin area.

No sample employment history, qualifications, awards, clients, or project claims are included. Add verified details through the admin tools as they become available.
