<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$statement = $pdo->prepare("SELECT p.*, c.name AS category_name FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id WHERE p.slug = ? AND p.status = 'published'");
$statement->execute([trim((string) ($_GET['slug'] ?? ''))]);
$post = $statement->fetch();
if (!$post) { http_response_code(404); $pageTitle = 'Article not found'; require __DIR__ . '/includes/header.php'; echo '<section class="page-hero"><h1>Article not found.</h1><a class="text-link" href="blog.php">Back to journal</a></section>'; require __DIR__ . '/includes/footer.php'; exit; }
$pageTitle = $post['title'] . ' | ' . ($profile['name'] ?? 'Kukumba Daphine');
require __DIR__ . '/includes/header.php';
?>
<article class="article-page"><p class="eyebrow"><?= e($post['category_name'] ?? 'JOURNAL') ?> · <?= e($post['published_at'] ? date('M j, Y', strtotime($post['published_at'])) : '') ?></p><h1><?= e($post['title']) ?></h1><p class="article-lead"><?= e($post['excerpt']) ?></p><?php if ($post['featured_image']): ?><img class="article-cover" src="<?= e($post['featured_image']) ?>" alt=""><?php endif; ?><div class="article-body"><?= nl2br(e($post['body'])) ?></div></article>
<?php require __DIR__ . '/includes/footer.php'; ?>
