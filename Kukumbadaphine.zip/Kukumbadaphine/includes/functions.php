<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    $isSecure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'httponly' => true,
        'secure' => $isSecure,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/secrets.php';

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function social_icon(string $label): string
{
    $name = strtolower($label);
    $icon = match (true) {
        str_contains($name, 'linkedin') => '<path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14ZM8.34 17.5V9.7H5.75v7.8h2.59ZM7.05 8.64a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm11.2 8.86v-4.27c0-2.29-1.22-3.36-2.85-3.36a2.46 2.46 0 0 0-2.22 1.22V9.7h-2.59v7.8h2.59v-4.27c0-1.12.21-2.21 1.6-2.21 1.37 0 1.39 1.29 1.39 2.28v4.2h2.08Z"/>',
        str_contains($name, 'github') => '<path d="M12 .9a11.1 11.1 0 0 0-3.51 21.63c.56.1.76-.24.76-.54v-2.1c-3.1.67-3.76-1.32-3.76-1.32-.51-1.3-1.24-1.65-1.24-1.65-1.01-.69.08-.68.08-.68 1.12.08 1.71 1.15 1.71 1.15 1 1.7 2.62 1.21 3.26.93.1-.72.39-1.21.71-1.49-2.47-.28-5.07-1.24-5.07-5.5 0-1.22.44-2.21 1.15-2.99-.12-.28-.5-1.42.11-2.95 0 0 .94-.3 3.05 1.14a10.6 10.6 0 0 1 5.55 0c2.12-1.44 3.05-1.14 3.05-1.14.61 1.53.23 2.67.12 2.95.71.78 1.14 1.77 1.14 2.99 0 4.27-2.61 5.21-5.1 5.49.4.35.76 1.02.76 2.06v3.11c0 .3.2.65.77.54A11.1 11.1 0 0 0 12 .9Z"/>',
        str_contains($name, 'instagram') => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.8" r="1" class="social-icon-dot"/>',
        str_contains($name, 'facebook') => '<path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.3v3h2.8v8h3.4Z"/>',
        str_contains($name, 'youtube') => '<path d="M23 7.1a3 3 0 0 0-2.1-2.2C19 4.4 12 4.4 12 4.4s-7 0-8.9.5A3 3 0 0 0 1 7.1 31 31 0 0 0 .5 12a31 31 0 0 0 .5 4.9 3 3 0 0 0 2.1 2.2c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.2 31 31 0 0 0 .5-4.9 31 31 0 0 0-.5-4.9ZM9.8 15.7V8.3l6.3 3.7-6.3 3.7Z"/>',
        str_contains($name, 'whatsapp') => '<path d="M20.5 3.5A11.9 11.9 0 0 0 1.8 17.8L.2 23.7l6-1.6a11.9 11.9 0 0 0 14.3-18.6ZM12 21a9 9 0 0 1-4.6-1.3l-.3-.2-3.5.9.9-3.4-.2-.4A9 9 0 1 1 12 21Zm5-6.7c-.3-.2-1.7-.9-2-.9s-.5-.2-.7.2-.8.9-1 1.1-.4.2-.7.1a7.4 7.4 0 0 1-2.2-1.4 8.3 8.3 0 0 1-1.5-1.9c-.2-.3 0-.5.2-.7l.5-.6.3-.5c.1-.2 0-.4 0-.6l-.9-2.1c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.4-1.2 1.2-1.2 2.8s1.2 3.1 1.4 3.4c.2.2 2.4 3.6 5.8 5 .8.3 1.4.5 1.9.6.8.2 1.5.2 2 .1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.3-.6-.5Z"/>',
        str_contains($name, 'tiktok') => '<path d="M19.6 6.4a5.3 5.3 0 0 1-3.2-3.8V2h-3.5v13.6a2.9 2.9 0 1 1-2.9-2.9c.3 0 .7 0 1 .1V9.2a7 7 0 1 0 5.4 6.8V9.1a8.8 8.8 0 0 0 5.1 1.6V7.2c-.7 0-1.3-.3-1.9-.8Z"/>',
        str_contains($name, 'twitter'), trim($name) === 'x', str_contains($name, ' x ') => '<path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3L12 14.9 5.8 22H2.6l7.3-8.4L1.8 2h6.5l4.5 6.7L18.9 2Zm-1.1 18h1.7L7.3 3.9H5.5L17.8 20Z"/>',
        default => '<path d="M10.6 13.4a1 1 0 0 0 1.4 1.4l4.2-4.2a3.5 3.5 0 0 0-5-5L9 7.8a1 1 0 1 0 1.4 1.4l2.2-2.2a1.5 1.5 0 1 1 2.2 2.2l-4.2 4.2ZM13.4 10.6a1 1 0 0 0-1.4-1.4l-4.2 4.2a3.5 3.5 0 0 0 5 5l2.2-2.2a1 1 0 1 0-1.4-1.4l-2.2 2.2a1.5 1.5 0 1 1-2.2-2.2l4.2-4.2Z"/>',
    };

    return '<svg class="social-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $icon . '</svg>';
}

function utf8_length(string $value): ?int
{
    $length = preg_match_all('/./us', $value, $matches);
    return $length === false ? null : $length;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (!is_string($submitted) || !hash_equals(csrf_token(), $submitted)) {
        http_response_code(403);
        exit('The request could not be verified. Reload the page and try again.');
    }
}

function is_admin(): bool
{
    return isset($_SESSION['admin_id']);
}

function require_admin(): void
{
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}

function profile(PDO $pdo): array
{
    $row = $pdo->query('SELECT * FROM profile WHERE id = 1')->fetch();
    return $row ?: [];
}

function setting(PDO $pdo, string $key, string $default = ''): string
{
    $statement = $pdo->prepare('SELECT setting_value FROM site_settings WHERE setting_key = ?');
    $statement->execute([$key]);
    $value = $statement->fetchColumn();
    return $value === false ? $default : (string) $value;
}

function openai_api_key(PDO $pdo): string
{
    $environmentKey = trim((string) getenv('OPENAI_API_KEY'));
    if ($environmentKey !== '') {
        return $environmentKey;
    }

    $encryptedKey = setting($pdo, 'ai_api_key_encrypted');
    return $encryptedKey === '' ? '' : decrypt_secret($encryptedKey);
}

function upload_file(string $field, string $directory, array $allowedMimes, int $maxBytes): ?string
{
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('The upload failed. Please choose the file again.');
    }
    if ($file['size'] <= 0 || $file['size'] > $maxBytes) {
        throw new RuntimeException('The selected file is empty or exceeds the size limit.');
    }

    $mime = null;
    if (str_starts_with((string) $file['type'], 'image/')) {
        $imageInfo = getimagesize($file['tmp_name']);
        $mime = is_array($imageInfo) ? ($imageInfo['mime'] ?? null) : null;
    } elseif (isset($allowedMimes['application/pdf'])) {
        $handle = fopen($file['tmp_name'], 'rb');
        if ($handle !== false) {
            $signature = fread($handle, 5);
            fclose($handle);
            if ($signature === '%PDF-') $mime = 'application/pdf';
        }
    }
    if (!isset($allowedMimes[$mime])) {
        throw new RuntimeException('That file type is not allowed.');
    }

    $targetDirectory = dirname(__DIR__) . '/uploads/' . $directory;
    if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0755, true) && !is_dir($targetDirectory)) {
        throw new RuntimeException('The upload directory could not be created.');
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowedMimes[$mime];
    if (!move_uploaded_file($file['tmp_name'], $targetDirectory . '/' . $filename)) {
        throw new RuntimeException('The uploaded file could not be saved.');
    }

    return 'uploads/' . $directory . '/' . $filename;
}

function remove_uploaded_file(?string $relativePath): void
{
    if (!$relativePath || !str_starts_with($relativePath, 'uploads/')) {
        return;
    }

    $root = realpath(dirname(__DIR__) . '/uploads');
    $path = realpath(dirname(__DIR__) . '/' . $relativePath);
    if ($root !== false && $path !== false && str_starts_with($path, $root . DIRECTORY_SEPARATOR) && is_file($path)) {
        unlink($path);
    }
}

function redirect_with_message(string $location, string $message, string $type = 'success'): never
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
    header('Location: ' . $location);
    exit;
}

function flash_message(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}
