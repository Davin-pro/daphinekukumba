<?php
declare(strict_types=1);

function app_encryption_key(): string
{
    $encodedKey = trim((string) getenv('APP_ENCRYPTION_KEY'));
    $key = base64_decode($encodedKey, true);
    if ($key === false || strlen($key) !== 32) {
        throw new RuntimeException('Configure APP_ENCRYPTION_KEY as a base64-encoded 32-byte key before saving an API key.');
    }

    return $key;
}

function encrypt_secret(string $secret): string
{
    if (!function_exists('openssl_encrypt')) {
        throw new RuntimeException('The PHP OpenSSL extension is required to encrypt the API key.');
    }

    $nonce = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt($secret, 'aes-256-gcm', app_encryption_key(), OPENSSL_RAW_DATA, $nonce, $tag, 'daphine-ai-api-key', 16);
    if ($ciphertext === false) {
        throw new RuntimeException('The API key could not be encrypted.');
    }

    return 'v1:' . base64_encode($nonce . $tag . $ciphertext);
}

function decrypt_secret(string $encryptedSecret): string
{
    if (!function_exists('openssl_decrypt')) {
        throw new RuntimeException('The PHP OpenSSL extension is required to decrypt the API key.');
    }

    $encodedPayload = substr($encryptedSecret, 3);
    $payload = str_starts_with($encryptedSecret, 'v1:') ? base64_decode($encodedPayload, true) : false;
    if ($payload === false || strlen($payload) < 29) {
        throw new RuntimeException('The saved API key is invalid. Remove it and save the key again.');
    }

    $nonce = substr($payload, 0, 12);
    $tag = substr($payload, 12, 16);
    $ciphertext = substr($payload, 28);
    $secret = openssl_decrypt($ciphertext, 'aes-256-gcm', app_encryption_key(), OPENSSL_RAW_DATA, $nonce, $tag, 'daphine-ai-api-key');
    if ($secret === false) {
        throw new RuntimeException('The saved API key could not be decrypted. Check APP_ENCRYPTION_KEY or save the key again.');
    }

    return $secret;
}
