<?php
$pageTitle = $pageTitle ?? (($profile['name'] ?? 'Kukumba Daphine') . ' | Computer Engineer');
$activePage = $activePage ?? '';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= e($profile['seo_description'] ?? 'Computer Engineer and Full-Stack Developer based in Uganda.') ?>">
    <title><?= e($pageTitle) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css?v=20261103-digital-twin">
</head>
<body>
<header class="site-header">
    <a class="brand" href="index.php"><span class="brand-mark">KD</span><span><?= e($profile['name'] ?? 'Kukumba Daphine') ?><small><?= e($profile['title'] ?? 'Computer Engineer') ?></small></span></a>
    <button class="menu-toggle" type="button" aria-label="Toggle navigation" aria-expanded="false"><span></span><span></span><span></span></button>
    <nav class="main-nav" aria-label="Main navigation">
        <a class="<?= $activePage === 'home' ? 'active' : '' ?>" href="index.php">Home</a>
        <a href="index.php#about">About</a>
        <a href="index.php#services">Services</a>
        <a class="<?= $activePage === 'projects' ? 'active' : '' ?>" href="projects.php">Projects</a>
        <a class="<?= $activePage === 'blog' ? 'active' : '' ?>" href="blog.php">Blog</a>
        <a href="contact.php">Contact</a>
        <a class="button button-small" href="contact.php">Hire Me <span aria-hidden="true">↗</span></a>
    </nav>
</header>
<main>
