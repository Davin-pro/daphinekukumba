</main>
<footer class="site-footer">
    <div class="footer-inner">
        <a class="brand" href="index.php"><span class="brand-mark">KD</span><span><?= e($profile['name'] ?? 'Kukumba Daphine') ?><small><?= e($profile['title'] ?? 'Computer Engineer') ?></small></span></a>
        <p>Building technology solutions that make an impact.</p>
        <div class="footer-links"><a href="index.php#about">About</a><a href="projects.php">Projects</a><a href="blog.php">Blog</a><a href="contact.php">Contact</a></div>
        <small>© <?= date('Y') ?> <?= e($profile['name'] ?? 'Kukumba Daphine') ?>. All rights reserved.</small>
        <?php if (empty($profile['hero_image']) || $profile['hero_image'] === 'assets/images/canadian-rockies.jpg'): ?><small class="photo-credit">Hero photograph by <a href="https://commons.wikimedia.org/wiki/File:1_lake_louise_pano_2019.jpg" target="_blank" rel="noopener noreferrer">Chensiyuan</a>, used under <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener noreferrer">CC BY-SA 4.0</a>.</small><?php endif; ?>
    </div>
</footer>
<section class="assistant-widget" id="assistantWidget" aria-label="Daphine AI chat" data-endpoint="api/assistant.php" data-csrf="<?= e(csrf_token()) ?>" data-enabled="<?= setting($pdo, 'ai_enabled', '0') === '1' ? 'true' : 'false' ?>">
    <div class="assistant-panel" id="assistantPanel" role="dialog" aria-modal="false" aria-labelledby="assistantTitle" aria-hidden="true" hidden>
        <header class="assistant-header">
            <span class="assistant-avatar" aria-hidden="true">DA</span>
            <div><h2 id="assistantTitle">DAPHINE AI</h2><p>Professional digital assistant</p></div>
            <button class="assistant-close" type="button" aria-label="Close chat">×</button>
        </header>
        <div class="assistant-messages" id="assistantMessages" role="log" aria-live="polite" aria-relevant="additions text"></div>
        <div class="assistant-suggestions" id="assistantSuggestions" aria-label="Suggested questions">
            <button type="button" data-question="Tell me about your professional background.">Background</button>
            <button type="button" data-question="What projects have you developed?">Projects</button>
            <button type="button" data-question="What are your technical skills?">Skills</button>
        </div>
        <form class="assistant-form" id="assistantForm">
            <label class="sr-only" for="assistantInput">Ask a question</label>
            <input id="assistantInput" name="question" type="text" maxlength="1000" placeholder="Ask Daphine..." autocomplete="off" required>
            <button type="submit" aria-label="Send message"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 20.5 22 12 3 3.5 3 10l13 2-13 2z"/></svg></button>
        </form>
        <p class="assistant-note" id="assistantStatus"><?= setting($pdo, 'ai_enabled', '0') === '1' ? 'AI answers based on verified portfolio information.' : 'The AI assistant is currently offline.' ?> Messages are sent to OpenAI and are not saved by this site.</p>
    </div>
    <button class="assistant-launcher" id="assistantLauncher" type="button" aria-expanded="false" aria-controls="assistantPanel" aria-label="Open Daphine AI chat">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-9l-5 3v-3H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm2 5v2h12V9zm0 4v2h8v-2z"/></svg>
        <span>Ask Daphine</span>
    </button>
</section>
<a class="whatsapp-float" href="https://wa.me/256705995085" target="_blank" rel="noopener noreferrer" aria-label="Chat with Kukumba Daphine on WhatsApp">
    <svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M16.04 3C8.87 3 3.04 8.82 3.03 15.98c0 2.28.6 4.5 1.75 6.46L3 29l6.73-1.76a13.04 13.04 0 0 0 6.3 1.6h.01c7.16 0 12.99-5.83 13-13 0-3.47-1.35-6.73-3.8-9.17A12.9 12.9 0 0 0 16.04 3Zm0 23.65h-.01c-1.94 0-3.85-.52-5.51-1.52l-.4-.24-3.99 1.05 1.06-3.88-.26-.4a10.76 10.76 0 0 1-1.65-5.68c0-5.94 4.83-10.77 10.78-10.77 2.88 0 5.59 1.12 7.63 3.16a10.7 10.7 0 0 1 3.15 7.63c0 5.95-4.84 10.78-10.79 10.78Zm5.91-8.07c-.32-.16-1.88-.93-2.17-1.03-.29-.1-.5-.16-.71.16-.21.32-.82 1.03-1 1.24-.19.21-.37.24-.69.08-.32-.16-1.34-.49-2.55-1.57-.94-.84-1.57-1.88-1.76-2.2-.18-.32-.02-.49.14-.65.14-.14.32-.37.48-.55.16-.19.21-.32.32-.53.1-.21.05-.4-.03-.56-.08-.16-.71-1.72-.98-2.36-.26-.62-.52-.54-.71-.55l-.61-.01c-.21 0-.56.08-.85.4-.29.32-1.11 1.08-1.11 2.64s1.14 3.07 1.3 3.28c.16.21 2.23 3.4 5.4 4.77.76.33 1.36.52 1.82.67.76.24 1.45.21 2 .13.61-.09 1.88-.77 2.15-1.51.26-.74.26-1.37.18-1.51-.08-.14-.29-.22-.61-.38Z"/></svg>
</a>
<script src="assets/js/app.js?v=20261103-digital-twin" defer></script>
</body>
</html>
