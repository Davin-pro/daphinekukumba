<?php
require_once __DIR__ . '/../includes/functions.php';
if (is_admin()) { header('Location: dashboard.php'); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $statement = $pdo->prepare('SELECT id, username, password_hash FROM admins WHERE username = ?');
    $statement->execute([$username]);
    $admin = $statement->fetch();
    if ($admin && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    }
    $errors[] = 'The username or password was not recognized.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin sign in | Kukumba Daphine</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="admin-body"><main class="login-shell"><div class="login-card"><a class="brand" href="../index.php"><span class="brand-mark">KD</span><span>Kukumba Daphine<small>Portfolio administration</small></span></a><p class="eyebrow">ADMIN ACCESS</p><h1>Welcome back.</h1><p class="muted">Sign in to manage your portfolio content.</p><?php foreach ($errors as $error): ?><div class="notice error"><?= e($error) ?></div><?php endforeach; ?><form class="admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Username<input name="username" required autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="button" type="submit">Sign in</button></form><a class="text-link" href="../index.php">← Back to website</a></div></main></body></html>
