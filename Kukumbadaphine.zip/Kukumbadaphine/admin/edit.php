<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$type = (string) ($_GET['type'] ?? '');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$tables = [
    'service' => 'services',
    'project' => 'projects',
    'post' => 'blog_posts',
    'experience' => 'experience',
    'education' => 'education',
];
if (!isset($tables[$type]) || !$id) {
    http_response_code(400);
    exit('Choose a valid item to edit.');
}

$query = $pdo->prepare('SELECT * FROM ' . $tables[$type] . ' WHERE id = ?');
$query->execute([$id]);
$item = $query->fetch();
if (!$item) {
    http_response_code(404);
    exit('The selected item was not found.');
}
$categories = $type === 'post' ? $pdo->query('SELECT * FROM blog_categories ORDER BY name')->fetchAll() : [];
$csrf = csrf_token();
$backSection = match ($type) {
    'post' => 'blog',
    'service' => 'services',
    'experience' => 'experience',
    'education' => 'education',
    default => 'projects',
};
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Edit <?= e(ucfirst($type)) ?> | Portfolio admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="admin-body"><main class="edit-shell"><a class="text-link" href="dashboard.php#<?= e($backSection) ?>">← Back to dashboard</a><section class="admin-section"><div class="admin-section-heading"><div><p class="eyebrow">CONTENT MANAGEMENT</p><h2>Edit <?= e(ucfirst($type)) ?></h2></div></div>
<?php if ($type === 'experience' || $type === 'education'): ?>
<?php $organizationField = $type === 'education' ? 'institution' : 'organization'; $roleField = $type === 'education' ? 'qualification' : 'role'; ?>
<form class="admin-form admin-panel" method="post" action="dashboard.php"><input type="hidden" name="csrf_token" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="<?= e($type) ?>_save"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><label><?= $type === 'education' ? 'Institution' : 'Organization' ?><input name="<?= e($organizationField) ?>" required value="<?= e($item[$organizationField]) ?>"></label><label><?= $type === 'education' ? 'Qualification' : 'Role' ?><input name="<?= e($roleField) ?>" required value="<?= e($item[$roleField]) ?>"></label><div class="form-row"><label>Start date / year<input name="start_date" value="<?= e($item['start_date']) ?>"></label><label>End date / year<input name="end_date" value="<?= e($item['end_date']) ?>"></label></div><label>Details<textarea name="details" rows="5"><?= e($item['details']) ?></textarea></label><button class="button" type="submit">Save entry</button></form>
<?php elseif ($type === 'service'): ?>
<form class="admin-form admin-panel" method="post" action="dashboard.php"><input type="hidden" name="csrf_token" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="service_save"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><label>Service name<input name="name" required value="<?= e($item['name']) ?>"></label><label>Icon / symbol<input name="icon" maxlength="40" value="<?= e($item['icon']) ?>"></label><label>Description<textarea name="description" rows="4" required><?= e($item['description']) ?></textarea></label><button class="button" type="submit">Save service</button></form>
<?php elseif ($type === 'project'): ?>
<form class="admin-form admin-panel" method="post" action="dashboard.php" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="project_save"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><div class="admin-fields"><label>Project title<input name="title" required value="<?= e($item['title']) ?>"></label><label>Category<input name="category" value="<?= e($item['category']) ?>"></label><label>Description<input name="description" required value="<?= e($item['description']) ?>"></label><label>Technologies<input name="technologies" value="<?= e($item['technologies']) ?>"></label><label>Live link<input type="url" name="live_url" value="<?= e($item['live_url']) ?>"></label><label>GitHub link<input type="url" name="github_url" value="<?= e($item['github_url']) ?>"></label><label>Project details<textarea name="details" rows="7"><?= e($item['details']) ?></textarea></label><label>Replace image<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><?php if ($item['image']): ?><small class="muted">Current image: <?= e(basename($item['image'])) ?></small><?php endif; ?></label></div><label class="inline-check"><input type="checkbox" name="featured" value="1" <?= $item['featured'] ? 'checked' : '' ?>> Feature on homepage</label><button class="button" type="submit">Save project</button></form>
<?php else: ?>
<form class="admin-form admin-panel" method="post" action="dashboard.php" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="post_save"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><div class="admin-fields"><label>Title<input name="title" required value="<?= e($item['title']) ?>"></label><label>Category<select name="category_id"><option value="">Uncategorized</option><?php foreach ($categories as $category): ?><option value="<?= (int) $category['id'] ?>" <?= (int) $item['category_id'] === (int) $category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option><?php endforeach; ?></select></label><label>Summary<textarea name="excerpt" rows="3" required><?= e($item['excerpt']) ?></textarea></label><label>Article text<textarea name="body" rows="12" required><?= e($item['body']) ?></textarea></label><label>Replace featured image<input type="file" name="featured_image" accept="image/jpeg,image/png,image/webp"><?php if ($item['featured_image']): ?><small class="muted">Current image: <?= e(basename($item['featured_image'])) ?></small><?php endif; ?></label><label>Status<select name="status"><option value="draft" <?= $item['status'] === 'draft' ? 'selected' : '' ?>>Draft</option><option value="published" <?= $item['status'] === 'published' ? 'selected' : '' ?>>Published</option></select></label></div><button class="button" type="submit">Save article</button></form>
<?php endif; ?>
</section></main></body></html>
