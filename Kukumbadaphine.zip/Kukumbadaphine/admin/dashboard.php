<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    try {
        switch ($action) {
            case 'hero_restore_default':
                $current = $pdo->query('SELECT hero_image FROM profile WHERE id = 1')->fetchColumn();
                remove_uploaded_file(is_string($current) ? $current : null);
                $statement = $pdo->prepare("UPDATE profile SET hero_image = 'assets/images/canadian-rockies.jpg', hero_position_x = '50%', hero_position_y = '50%' WHERE id = 1");
                $statement->execute();
                redirect_with_message('dashboard.php#profile', 'Default scenic hero background restored.');

            case 'profile':
                $fields = ['name', 'title', 'hero_title', 'hero_intro', 'about_heading', 'biography', 'about_more', 'location', 'email', 'phone', 'languages', 'experience_stat', 'projects_stat', 'skills_stat', 'roles_stat', 'seo_description'];
                $values = [];
                foreach ($fields as $field) $values[$field] = trim((string) ($_POST[$field] ?? ''));
                if ($values['name'] === '' || !filter_var($values['email'], FILTER_VALIDATE_EMAIL) && $values['email'] !== '') {
                    throw new RuntimeException('Enter a name and a valid email address (or leave email blank).');
                }
                foreach (['hero_position_x', 'hero_position_y'] as $field) {
                    $position = filter_var($_POST[$field] ?? '50', FILTER_VALIDATE_INT);
                    if ($position === false || $position < 0 || $position > 100) {
                        throw new RuntimeException('Hero image positioning must be between 0 and 100 percent.');
                    }
                    $values[$field] = $position . '%';
                }
                foreach (['portrait_position_x', 'portrait_position_y'] as $field) {
                    $position = filter_var($_POST[$field] ?? '50', FILTER_VALIDATE_INT);
                    if ($position === false || $position < 0 || $position > 100) {
                        throw new RuntimeException('Portrait positioning must be between 0 and 100 percent.');
                    }
                    $values[$field] = $position . '%';
                }
                $portraitFit = (string) ($_POST['portrait_fit'] ?? 'contain');
                if (!in_array($portraitFit, ['contain', 'cover'], true)) {
                    throw new RuntimeException('Choose a valid portrait crop mode.');
                }
                $values['portrait_fit'] = $portraitFit;
                foreach (['portrait' => ['profile', ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'], 5 * 1024 * 1024], 'hero_image' => ['backgrounds', ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'], 8 * 1024 * 1024], 'cv_file' => ['cv', ['application/pdf' => 'pdf'], 10 * 1024 * 1024]] as $field => [$directory, $types, $maxSize]) {
                    $uploaded = upload_file($field, $directory, $types, $maxSize);
                    if ($uploaded !== null) {
                        $current = $pdo->query('SELECT ' . $field . ' FROM profile WHERE id = 1')->fetchColumn();
                        $values[$field] = $uploaded;
                        remove_uploaded_file(is_string($current) ? $current : null);
                    } elseif (isset($_POST['remove_' . $field])) {
                        $current = $pdo->query('SELECT ' . $field . ' FROM profile WHERE id = 1')->fetchColumn();
                        $values[$field] = null;
                        remove_uploaded_file(is_string($current) ? $current : null);
                    }
                }
                $assignments = [];
                foreach ($values as $field => $value) $assignments[] = $field . ' = :' . $field;
                $statement = $pdo->prepare('UPDATE profile SET ' . implode(', ', $assignments) . ' WHERE id = 1');
                $statement->execute($values);
                redirect_with_message('dashboard.php#profile', 'Profile information updated.');

            case 'service_save':
                $id = (int) ($_POST['id'] ?? 0);
                $name = trim((string) ($_POST['name'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $icon = trim((string) ($_POST['icon'] ?? '*'));
                if ($name === '' || $description === '') throw new RuntimeException('A service name and description are required.');
                if ($id > 0) {
                    $statement = $pdo->prepare('UPDATE services SET name = ?, description = ?, icon = ? WHERE id = ?');
                    $statement->execute([$name, $description, $icon, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO services (name, description, icon) VALUES (?, ?, ?)');
                    $statement->execute([$name, $description, $icon]);
                }
                redirect_with_message('dashboard.php#services', 'Service saved.');

            case 'service_delete':
                $statement = $pdo->prepare('DELETE FROM services WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#services', 'Service removed.');

            case 'skill_save':
                $name = trim((string) ($_POST['name'] ?? ''));
                if ($name === '') throw new RuntimeException('Enter a skill name.');
                $statement = $pdo->prepare('INSERT INTO skills (name) VALUES (?)');
                $statement->execute([$name]);
                redirect_with_message('dashboard.php#skills', 'Skill added.');

            case 'skill_delete':
                $statement = $pdo->prepare('DELETE FROM skills WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#skills', 'Skill removed.');

            case 'ai_settings_save':
                $enabled = isset($_POST['ai_enabled']) ? '1' : '0';
                $knowledge = trim((string) ($_POST['ai_knowledge'] ?? ''));
                $knowledgeLength = utf8_length($knowledge);
                if ($knowledgeLength === null || $knowledgeLength > 20000) throw new RuntimeException('Additional AI knowledge must be 20,000 characters or fewer.');
                $apiKey = trim((string) ($_POST['ai_api_key'] ?? ''));
                $removeApiKey = isset($_POST['remove_ai_api_key']);
                if ($apiKey !== '' && (!preg_match('/^sk-[A-Za-z0-9_-]{20,}$/', $apiKey) || strlen($apiKey) > 512)) {
                    throw new RuntimeException('Enter a valid OpenAI API key. The key must start with sk- and contain only letters, numbers, underscores, and hyphens.');
                }
                if ($apiKey !== '' && $removeApiKey) {
                    throw new RuntimeException('Choose either a replacement API key or remove the saved key, not both.');
                }
                $storedApiKey = setting($pdo, 'ai_api_key_encrypted');
                $environmentApiKey = trim((string) getenv('OPENAI_API_KEY'));
                if ($apiKey !== '') {
                    $storedApiKey = encrypt_secret($apiKey);
                } elseif ($removeApiKey) {
                    $storedApiKey = '';
                }
                if ($enabled === '1' && $environmentApiKey === '') {
                    if ($storedApiKey === '') {
                        throw new RuntimeException('Save an OpenAI API key before enabling Daphine AI.');
                    }
                    decrypt_secret($storedApiKey);
                }
                $statement = $pdo->prepare('INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
                $statement->execute(['ai_enabled', $enabled]);
                $statement->execute(['ai_knowledge', $knowledge]);
                $statement->execute(['ai_api_key_encrypted', $storedApiKey]);
                redirect_with_message('dashboard.php#ai', 'Daphine AI settings saved.');

            case 'timeline_save':
                $id = (int) ($_POST['id'] ?? 0);
                $period = trim((string) ($_POST['period'] ?? ''));
                $title = trim((string) ($_POST['title'] ?? ''));
                $role = trim((string) ($_POST['role'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $technologies = trim((string) ($_POST['technologies'] ?? ''));
                $sortOrder = (int) ($_POST['sort_order'] ?? 0);
                if ($period === '' || $title === '' || $description === '' ||
                    ($periodLength = utf8_length($period)) === null || $periodLength > 80 ||
                    ($titleLength = utf8_length($title)) === null || $titleLength > 190 ||
                    ($roleLength = utf8_length($role)) === null || $roleLength > 190 ||
                    ($descriptionLength = utf8_length($description)) === null || $descriptionLength > 10000 ||
                    ($technologiesLength = utf8_length($technologies)) === null || $technologiesLength > 500) {
                    throw new RuntimeException('Enter a valid period, title, and description within the field limits.');
                }
                if ($id > 0) {
                    $statement = $pdo->prepare('UPDATE timeline_events SET period=?, title=?, role=?, description=?, technologies=?, sort_order=? WHERE id=?');
                    $statement->execute([$period, $title, $role, $description, $technologies, $sortOrder, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO timeline_events (period, title, role, description, technologies, sort_order) VALUES (?, ?, ?, ?, ?, ?)');
                    $statement->execute([$period, $title, $role, $description, $technologies, $sortOrder]);
                }
                redirect_with_message('dashboard.php#timeline', 'Professional journey entry saved.');

            case 'timeline_delete':
                $statement = $pdo->prepare('DELETE FROM timeline_events WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#timeline', 'Professional journey entry removed.');

            case 'interest_save':
                $id = (int) ($_POST['id'] ?? 0);
                $name = trim((string) ($_POST['name'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                $icon = trim((string) ($_POST['icon'] ?? '✦'));
                $sortOrder = (int) ($_POST['sort_order'] ?? 0);
                if ($name === '' || $description === '' ||
                    ($nameLength = utf8_length($name)) === null || $nameLength > 120 ||
                    ($descriptionLength = utf8_length($description)) === null || $descriptionLength > 500 ||
                    ($iconLength = utf8_length($icon)) === null || $iconLength > 40) {
                    throw new RuntimeException('Enter an interest name and description within the field limits.');
                }
                if ($id > 0) {
                    $duplicate = $pdo->prepare('SELECT id FROM innovation_interests WHERE name = ? AND id != ?');
                    $duplicate->execute([$name, $id]);
                    if ($duplicate->fetchColumn()) throw new RuntimeException('That interest already exists.');
                }
                if ($id > 0) {
                    $statement = $pdo->prepare('UPDATE innovation_interests SET name=?, description=?, icon=?, sort_order=? WHERE id=?');
                    $statement->execute([$name, $description, $icon, $sortOrder, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO innovation_interests (name, description, icon, sort_order) VALUES (?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE description=VALUES(description), icon=VALUES(icon), sort_order=VALUES(sort_order)');
                    $statement->execute([$name, $description, $icon, $sortOrder]);
                }
                redirect_with_message('dashboard.php#interests', 'Innovation radar updated.');

            case 'interest_delete':
                $statement = $pdo->prepare('DELETE FROM innovation_interests WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#interests', 'Interest removed.');

            case 'terminal_command_save':
                $id = (int) ($_POST['id'] ?? 0);
                $command = strtolower(trim((string) ($_POST['command'] ?? '')));
                $description = trim((string) ($_POST['description'] ?? ''));
                $output = trim((string) ($_POST['output'] ?? ''));
                $builtInCommands = ['help', 'about', 'skills', 'projects', 'experience', 'education', 'services', 'articles', 'contact', 'ai', 'clear'];
                $descriptionLength = utf8_length($description);
                $outputLength = utf8_length($output);
                if (!preg_match('/^[a-z][a-z0-9_-]{0,39}$/', $command) || $description === '' ||
                    $descriptionLength === null || $descriptionLength > 190 || $outputLength === null || $outputLength > 2000) {
                    throw new RuntimeException('Enter a valid command and description. Custom command output is limited to 2,000 characters.');
                }
                if (in_array($command, $builtInCommands, true) && $output !== '') {
                    throw new RuntimeException('Built-in commands use live portfolio data and cannot have custom output.');
                }
                if (!in_array($command, $builtInCommands, true) && $output === '') {
                    throw new RuntimeException('Add plain-text output for each custom terminal command.');
                }
                $duplicate = $pdo->prepare('SELECT id FROM terminal_commands WHERE command = ? AND id != ?');
                $duplicate->execute([$command, $id]);
                if ($duplicate->fetchColumn()) throw new RuntimeException('That terminal command already exists.');
                if ($id > 0) {
                    $statement = $pdo->prepare('UPDATE terminal_commands SET command=?, description=?, output=? WHERE id=?');
                    $statement->execute([$command, $description, $output, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO terminal_commands (command, description, output) VALUES (?, ?, ?)');
                    $statement->execute([$command, $description, $output]);
                }
                redirect_with_message('dashboard.php#terminal-commands', 'Terminal command saved.');

            case 'terminal_command_delete':
                $commandId = (int) ($_POST['id'] ?? 0);
                $statement = $pdo->prepare('SELECT command FROM terminal_commands WHERE id = ?');
                $statement->execute([$commandId]);
                $commandName = $statement->fetchColumn();
                if (in_array($commandName, ['help', 'about', 'skills', 'projects', 'experience', 'education', 'services', 'articles', 'contact', 'ai', 'clear'], true)) {
                    throw new RuntimeException('Built-in commands cannot be removed.');
                }
                $statement = $pdo->prepare('DELETE FROM terminal_commands WHERE id = ?');
                $statement->execute([$commandId]);
                redirect_with_message('dashboard.php#terminal-commands', 'Custom terminal command removed.');

            case 'project_save':
                $id = (int) ($_POST['id'] ?? 0);
                $title = trim((string) ($_POST['title'] ?? ''));
                $description = trim((string) ($_POST['description'] ?? ''));
                if ($title === '' || $description === '') throw new RuntimeException('A project title and description are required.');
                $slug = strtolower(trim((string) preg_replace('/[^a-z0-9]+/i', '-', $title), '-'));
                if ($id === 0) $slug .= '-' . bin2hex(random_bytes(3));
                $image = upload_file('image', 'projects', ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'], 5 * 1024 * 1024);
                $fields = [
                    trim((string) ($_POST['category'] ?? '')),
                    $description,
                    trim((string) ($_POST['details'] ?? '')),
                    trim((string) ($_POST['technologies'] ?? '')),
                    trim((string) ($_POST['live_url'] ?? '')),
                    trim((string) ($_POST['github_url'] ?? '')),
                    isset($_POST['featured']) ? 1 : 0,
                ];
                foreach ([$fields[4], $fields[5]] as $url) {
                    if ($url !== '' && (!filter_var($url, FILTER_VALIDATE_URL) || !in_array(parse_url($url, PHP_URL_SCHEME), ['http', 'https'], true))) {
                        throw new RuntimeException('Project links must be complete http or https URLs.');
                    }
                }
                if ($id > 0) {
                    if ($image) {
                        $oldQuery = $pdo->prepare('SELECT image FROM projects WHERE id = ?');
                        $oldQuery->execute([$id]);
                        remove_uploaded_file($oldQuery->fetchColumn() ?: null);
                    } else {
                        $imageQuery = $pdo->prepare('SELECT image FROM projects WHERE id = ?');
                        $imageQuery->execute([$id]);
                        $image = $imageQuery->fetchColumn() ?: null;
                    }
                    $statement = $pdo->prepare('UPDATE projects SET title=?, category=?, description=?, details=?, technologies=?, live_url=?, github_url=?, featured=?, image=? WHERE id=?');
                    $statement->execute([$title, ...$fields, $image, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO projects (title, slug, category, description, details, technologies, live_url, github_url, featured, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                    $statement->execute([$title, $slug, ...$fields, $image]);
                }
                redirect_with_message('dashboard.php#projects', 'Project saved.');

            case 'project_delete':
                $statement = $pdo->prepare('SELECT image FROM projects WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                remove_uploaded_file($statement->fetchColumn() ?: null);
                $statement = $pdo->prepare('DELETE FROM projects WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#projects', 'Project removed.');

            case 'post_save':
                $id = (int) ($_POST['id'] ?? 0);
                $title = trim((string) ($_POST['title'] ?? ''));
                $excerpt = trim((string) ($_POST['excerpt'] ?? ''));
                $body = trim((string) ($_POST['body'] ?? ''));
                if ($title === '' || $excerpt === '' || $body === '') throw new RuntimeException('Article title, summary and article text are required.');
                $slug = strtolower(trim((string) preg_replace('/[^a-z0-9]+/i', '-', $title), '-'));
                if ($id === 0) $slug .= '-' . bin2hex(random_bytes(3));
                $categoryId = (int) ($_POST['category_id'] ?? 0) ?: null;
                $status = ($_POST['status'] ?? '') === 'published' ? 'published' : 'draft';
                $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;
                $image = upload_file('featured_image', 'blog', ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'], 5 * 1024 * 1024);
                if ($id > 0) {
                    if ($image) {
                        $old = $pdo->prepare('SELECT featured_image FROM blog_posts WHERE id=?');
                        $old->execute([$id]);
                        remove_uploaded_file($old->fetchColumn() ?: null);
                    } else {
                        $old = $pdo->prepare('SELECT featured_image FROM blog_posts WHERE id=?');
                        $old->execute([$id]);
                        $image = $old->fetchColumn() ?: null;
                    }
                    $statement = $pdo->prepare("UPDATE blog_posts SET category_id=?, title=?, excerpt=?, body=?, featured_image=?, status=?, published_at=CASE WHEN ? = ? THEN COALESCE(published_at, ?) ELSE NULL END WHERE id=?");
                    $statement->execute([$categoryId, $title, $excerpt, $body, $image, $status, $status, 'published', $publishedAt, $id]);
                } else {
                    $statement = $pdo->prepare('INSERT INTO blog_posts (category_id, title, slug, excerpt, body, featured_image, status, published_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                    $statement->execute([$categoryId, $title, $slug, $excerpt, $body, $image, $status, $publishedAt]);
                }
                redirect_with_message('dashboard.php#blog', 'Article saved.');

            case 'post_delete':
                $statement = $pdo->prepare('SELECT featured_image FROM blog_posts WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                remove_uploaded_file($statement->fetchColumn() ?: null);
                $statement = $pdo->prepare('DELETE FROM blog_posts WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#blog', 'Article removed.');

            case 'social_save':
                $label = trim((string) ($_POST['label'] ?? ''));
                $url = trim((string) ($_POST['url'] ?? ''));
                if ($label === '' || !filter_var($url, FILTER_VALIDATE_URL) || !in_array(parse_url($url, PHP_URL_SCHEME), ['http', 'https'], true)) throw new RuntimeException('Enter a label and a valid http or https social link.');
                $statement = $pdo->prepare('INSERT INTO social_links (label, url) VALUES (?, ?)');
                $statement->execute([$label, $url]);
                redirect_with_message('dashboard.php#social', 'Social link added.');

            case 'social_delete':
                $statement = $pdo->prepare('DELETE FROM social_links WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#social', 'Social link removed.');

            case 'experience_save':
            case 'education_save':
                $type = $action === 'experience_save' ? 'experience' : 'education';
                $organizationColumn = $type === 'education' ? 'institution' : 'organization';
                $roleColumn = $type === 'education' ? 'qualification' : 'role';
                $id = (int) ($_POST['id'] ?? 0);
                $organization = trim((string) ($_POST[$organizationColumn] ?? ''));
                $role = trim((string) ($_POST[$roleColumn] ?? ''));
                $details = trim((string) ($_POST['details'] ?? ''));
                $startDate = trim((string) ($_POST['start_date'] ?? ''));
                $endDate = trim((string) ($_POST['end_date'] ?? ''));
                if ($organization === '' || $role === '') throw new RuntimeException('An organization and role or qualification are required.');
                if ($id > 0) {
                    $statement = $pdo->prepare("UPDATE {$type} SET {$organizationColumn}=?, {$roleColumn}=?, details=?, start_date=?, end_date=? WHERE id=?");
                    $statement->execute([$organization, $role, $details, $startDate ?: null, $endDate ?: null, $id]);
                } else {
                    $statement = $pdo->prepare("INSERT INTO {$type} ({$organizationColumn}, {$roleColumn}, details, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
                    $statement->execute([$organization, $role, $details, $startDate ?: null, $endDate ?: null]);
                }
                redirect_with_message('dashboard.php#' . $type, ucfirst($type) . ' entry saved.');

            case 'experience_delete':
            case 'education_delete':
                $type = $action === 'experience_delete' ? 'experience' : 'education';
                $statement = $pdo->prepare("DELETE FROM {$type} WHERE id = ?");
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#' . $type, ucfirst($type) . ' entry removed.');

            case 'message_read':
                $statement = $pdo->prepare('UPDATE contact_messages SET is_read = 1 WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#messages', 'Message marked as read.');

            case 'message_delete':
                $statement = $pdo->prepare('DELETE FROM contact_messages WHERE id = ?');
                $statement->execute([(int) ($_POST['id'] ?? 0)]);
                redirect_with_message('dashboard.php#messages', 'Message deleted.');

            case 'password_change':
                $current = (string) ($_POST['current_password'] ?? '');
                $new = (string) ($_POST['new_password'] ?? '');
                if (strlen($new) < 12) throw new RuntimeException('Choose a new password with at least 12 characters.');
                $statement = $pdo->prepare('SELECT password_hash FROM admins WHERE id = ?');
                $statement->execute([$_SESSION['admin_id']]);
                $hash = $statement->fetchColumn();
                if (!$hash || !password_verify($current, $hash)) throw new RuntimeException('The current password is incorrect.');
                $statement = $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
                $statement->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['admin_id']]);
                redirect_with_message('dashboard.php#account', 'Password changed.');

            default:
                throw new RuntimeException('Unknown dashboard action.');
        }
    } catch (RuntimeException $exception) {
        redirect_with_message('dashboard.php', $exception->getMessage(), 'error');
    }
}

$profile = profile($pdo);
$services = $pdo->query('SELECT * FROM services ORDER BY sort_order, id')->fetchAll();
$projects = $pdo->query('SELECT * FROM projects ORDER BY created_at DESC')->fetchAll();
$skills = $pdo->query('SELECT * FROM skills ORDER BY sort_order, id')->fetchAll();
$posts = $pdo->query('SELECT p.*, c.name AS category_name FROM blog_posts p LEFT JOIN blog_categories c ON c.id=p.category_id ORDER BY p.created_at DESC')->fetchAll();
$categories = $pdo->query('SELECT * FROM blog_categories ORDER BY name')->fetchAll();
$socialLinks = $pdo->query('SELECT * FROM social_links ORDER BY sort_order, id')->fetchAll();
$education = $pdo->query('SELECT * FROM education ORDER BY end_date DESC, id DESC')->fetchAll();
$experience = $pdo->query('SELECT * FROM experience ORDER BY end_date DESC, id DESC')->fetchAll();
$timelineEvents = $pdo->query('SELECT * FROM timeline_events ORDER BY sort_order, id DESC')->fetchAll();
$interests = $pdo->query('SELECT * FROM innovation_interests ORDER BY sort_order, id')->fetchAll();
$terminalCommands = $pdo->query('SELECT * FROM terminal_commands ORDER BY id')->fetchAll();
$aiEnabled = setting($pdo, 'ai_enabled', '0') === '1';
$aiKnowledge = setting($pdo, 'ai_knowledge');
$savedAiApiKey = setting($pdo, 'ai_api_key_encrypted');
$aiApiKeyConfigured = trim((string) getenv('OPENAI_API_KEY')) !== '' || $savedAiApiKey !== '';
$aiApiKeySource = trim((string) getenv('OPENAI_API_KEY')) !== '' ? 'Server environment variable' : ($savedAiApiKey !== '' ? 'Encrypted dashboard storage' : 'Not configured');
$aiUsage = $pdo->query('SELECT COUNT(*) AS total, COALESCE(SUM(success), 0) AS successful, COALESCE(SUM(prompt_tokens + completion_tokens), 0) AS tokens FROM ai_usage')->fetch();
$messages = $pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 100')->fetchAll();
$counts = [
    'projects' => (int) $pdo->query('SELECT COUNT(*) FROM projects')->fetchColumn(),
    'posts' => (int) $pdo->query('SELECT COUNT(*) FROM blog_posts')->fetchColumn(),
    'messages' => (int) $pdo->query('SELECT COUNT(*) FROM contact_messages WHERE is_read=0')->fetchColumn(),
    'services' => (int) $pdo->query('SELECT COUNT(*) FROM services')->fetchColumn(),
];
$flash = flash_message();
$profileFields = [
    'name' => 'Full name', 'title' => 'Professional title', 'hero_title' => 'Hero title',
    'hero_intro' => 'Hero introduction', 'about_heading' => 'About heading', 'biography' => 'Biography',
    'about_more' => 'Additional biography', 'location' => 'Location', 'email' => 'Email',
    'phone' => 'Phone (international format preferred)', 'languages' => 'Languages',
    'experience_stat' => 'Experience card', 'projects_stat' => 'Projects card',
    'skills_stat' => 'Skills card', 'roles_stat' => 'Professional roles card',
    'seo_description' => 'SEO description',
];
$longFields = ['hero_intro', 'biography', 'about_more', 'seo_description'];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dashboard | Kukumba Daphine</title><link rel="stylesheet" href="../assets/css/style.css?v=20261103-digital-twin"></head>
<body class="admin-body">
<aside class="admin-sidebar"><a class="brand" href="../index.php"><span class="brand-mark">KD</span><span>Kukumba Daphine<small>Portfolio admin</small></span></a><p class="sidebar-label">WORKSPACE</p><nav><a href="#overview">Overview</a><a href="#profile">Profile & media</a><a href="#services">Services</a><a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#blog">Blog</a><a href="#ai">Daphine AI</a><a href="#timeline">Journey</a><a href="#interests">Innovation radar</a><a href="#terminal-commands">Terminal</a><a href="#social">Social links</a><a href="#messages">Messages <b><?= $counts['messages'] ?></b></a><a href="#account">Account</a></nav><a class="sidebar-site-link" href="../index.php" target="_blank">View website ↗</a><form method="post" action="logout.php"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><button class="sidebar-logout" type="submit">Sign out</button></form></aside>
<main class="admin-main">
    <header class="admin-topbar"><div><p class="eyebrow">PORTFOLIO MANAGEMENT</p><h1>Dashboard</h1></div><span class="admin-user"><?= e($_SESSION['admin_username'] ?? 'Administrator') ?></span></header>
    <?php if ($flash): ?><div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
    <section class="admin-section" id="overview"><div class="admin-stats"><?php foreach (['projects'=>'Projects','services'=>'Services','posts'=>'Articles','messages'=>'Unread messages'] as $key=>$label): ?><article class="admin-stat"><span><?= e($label) ?></span><strong><?= $counts[$key] ?></strong></article><?php endforeach; ?></div><p class="muted">Update content below; changes are reflected on the public portfolio immediately.</p></section>
    <section class="admin-section" id="profile">
        <div class="admin-section-heading"><div><p class="eyebrow">PUBLIC PROFILE</p><h2>Profile & media</h2></div></div>
        <form class="admin-form admin-panel" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="profile">
            <div class="admin-fields">
                <?php foreach ($profileFields as $field => $label): ?>
                    <label><?= e($label) ?>
                        <?php if (in_array($field, $longFields, true)): ?>
                            <textarea name="<?= e($field) ?>" rows="<?= $field === 'seo_description' ? 2 : 4 ?>"><?= e($profile[$field] ?? '') ?></textarea>
                        <?php else: ?>
                            <input name="<?= e($field) ?>" value="<?= e($profile[$field] ?? '') ?>" <?= $field === 'email' ? 'type="email"' : '' ?>>
                        <?php endif; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="hero-image-settings">
                <h3>Scenic hero background</h3>
                <p class="muted">A full-width mountain lake image is always used. Upload a replacement or restore the bundled default photograph.</p>
                <div class="hero-preview" id="heroPreview" style="background-image:linear-gradient(rgba(7,20,33,.2),rgba(7,20,33,.2)),url('../<?= e($profile['hero_image'] ?: 'assets/images/canadian-rockies.jpg') ?>');background-position:<?= e($profile['hero_position_x'] ?? '50%') ?> <?= e($profile['hero_position_y'] ?? '50%') ?>"></div>
                <label>Replace background image<input id="heroImageInput" type="file" name="hero_image" accept="image/jpeg,image/png,image/webp"><small class="muted">JPEG, PNG or WebP · maximum 8 MB. Preview changes are not saved until you click Save profile.</small></label>
                <div class="position-controls">
                    <label>Horizontal position: <output id="heroPositionXOutput"><?= e(rtrim($profile['hero_position_x'] ?? '50%', '%')) ?>%</output><input class="hero-position" id="heroPositionX" type="range" name="hero_position_x" min="0" max="100" value="<?= (int) rtrim($profile['hero_position_x'] ?? '50%', '%') ?>"></label>
                    <label>Vertical position: <output id="heroPositionYOutput"><?= e(rtrim($profile['hero_position_y'] ?? '50%', '%')) ?>%</output><input class="hero-position" id="heroPositionY" type="range" name="hero_position_y" min="0" max="100" value="<?= (int) rtrim($profile['hero_position_y'] ?? '50%', '%') ?>"></label>
                </div>
                <div class="hero-setting-actions"><button class="button" type="submit">Save profile & background</button></div>
            </div>
            <div class="upload-grid">
                <div class="portrait-editor">
                    <h3>Hero portrait</h3>
                    <p class="muted">Your portrait is layered directly over the mountain scene. A transparent PNG blends best; no avatar, border, or photo card is added.</p>
                    <div class="portrait-preview" id="portraitPreview">
                        <?php if (!empty($profile['portrait'])): ?>
                            <img id="portraitPreviewImage" src="../<?= e($profile['portrait']) ?>" alt="Current portrait preview" style="object-fit:<?= e($profile['portrait_fit'] ?? 'contain') ?>;object-position:<?= e($profile['portrait_position_x'] ?? '50%') ?> <?= e($profile['portrait_position_y'] ?? '50%') ?>">
                        <?php else: ?>
                            <img id="portraitPreviewImage" alt="Portrait preview" hidden>
                        <?php endif; ?>
                    </div>
                    <label>Upload or replace portrait<input id="portraitImageInput" type="file" name="portrait" accept="image/jpeg,image/png,image/webp"><small class="muted">JPG, PNG or WebP · maximum 5 MB. Preview changes are not saved until you click Save profile.</small></label>
                    <?php if (!empty($profile['portrait'])): ?><label class="inline-check"><input type="checkbox" name="remove_portrait" value="1"> Remove current portrait</label><?php endif; ?>
                    <div class="portrait-controls">
                        <label>Crop mode<select id="portraitFit" name="portrait_fit"><option value="contain" <?= ($profile['portrait_fit'] ?? 'contain') === 'contain' ? 'selected' : '' ?>>Fit full portrait</option><option value="cover" <?= ($profile['portrait_fit'] ?? 'contain') === 'cover' ? 'selected' : '' ?>>Fill and crop</option></select></label>
                        <label>Horizontal position: <output id="portraitPositionXOutput"><?= e(rtrim($profile['portrait_position_x'] ?? '50%', '%')) ?>%</output><input id="portraitPositionX" type="range" name="portrait_position_x" min="0" max="100" value="<?= (int) rtrim($profile['portrait_position_x'] ?? '50%', '%') ?>"></label>
                        <label>Vertical position: <output id="portraitPositionYOutput"><?= e(rtrim($profile['portrait_position_y'] ?? '50%', '%')) ?>%</output><input id="portraitPositionY" type="range" name="portrait_position_y" min="0" max="100" value="<?= (int) rtrim($profile['portrait_position_y'] ?? '50%', '%') ?>"></label>
                    </div>
                </div>
                <label>CV / resume PDF<input type="file" name="cv_file" accept=".pdf,application/pdf">
                    <?php if (!empty($profile['cv_file'])): ?><small class="muted">Current file: <a href="../<?= e($profile['cv_file']) ?>" target="_blank"><?= e(basename($profile['cv_file'])) ?></a></small><label class="inline-check"><input type="checkbox" name="remove_cv_file" value="1"> Remove current file</label><?php endif; ?>
                </label>
            </div>
            <p class="muted">Portrait image: JPEG, PNG or WebP up to 5 MB. Transparent PNG portraits blend best with the scenic background. CV: PDF up to 10 MB.</p>
            <button class="button" type="submit">Save profile</button>
        </form>
        <form class="restore-background-form" method="post" onsubmit="return confirm('Restore the original scenic hero background?')">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="hero_restore_default">
            <button class="button button-outline" type="submit">Restore default scenic background</button>
        </form>
    </section>
    <section class="admin-section" id="services"><div class="admin-section-heading"><div><p class="eyebrow">OFFERINGS</p><h2>Services</h2></div></div><form class="admin-form admin-panel inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="service_save"><label>Service name<input name="name" required></label><label>Icon / symbol<input name="icon" maxlength="40" value="*"></label><label>Description<input name="description" required></label><button class="button" type="submit">Add service</button></form><div class="admin-list"><?php foreach ($services as $item): ?><article><div><strong><?= e($item['name']) ?></strong><p><?= e($item['description']) ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="service_delete"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="skills"><div class="admin-section-heading"><div><p class="eyebrow">EXPERTISE</p><h2>Technical skills</h2></div></div><form class="admin-form admin-panel inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="skill_save"><label>Skill name<input name="name" required></label><button class="button" type="submit">Add skill</button></form><div class="admin-chip-list"><?php foreach ($skills as $skill): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="skill_delete"><input type="hidden" name="id" value="<?= (int) $skill['id'] ?>"><span><?= e($skill['name']) ?></span><button aria-label="Remove <?= e($skill['name']) ?>" type="submit">×</button></form><?php endforeach; ?></div></section>
    <section class="admin-section" id="projects"><div class="admin-section-heading"><div><p class="eyebrow">PORTFOLIO</p><h2>Add a project</h2></div></div><form class="admin-form admin-panel" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="project_save"><div class="admin-fields"><label>Project title<input name="title" required></label><label>Category<input name="category"></label><label>Description<input name="description" required></label><label>Technologies (comma separated)<input name="technologies"></label><label>Live link<input type="url" name="live_url"></label><label>GitHub link<input type="url" name="github_url"></label><label>Project details<textarea name="details" rows="4"></textarea></label><label>Thumbnail / screenshot<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label></div><label class="inline-check"><input type="checkbox" name="featured" value="1"> Feature on homepage</label><button class="button" type="submit">Publish project</button></form><div class="admin-list"><?php foreach ($projects as $item): ?><article><?php if ($item['image']): ?><img class="admin-thumb" src="../<?= e($item['image']) ?>" alt=""><?php endif; ?><div><strong><?= e($item['title']) ?></strong><p><?= e($item['category']) ?> · <?= e($item['technologies']) ?><?= $item['featured'] ? ' · Featured' : '' ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="project_delete"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="blog"><div class="admin-section-heading"><div><p class="eyebrow">JOURNAL</p><h2>Publish an article</h2></div></div><form class="admin-form admin-panel" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="post_save"><div class="admin-fields"><label>Title<input name="title" required></label><label>Category<select name="category_id"><option value="">Uncategorized</option><?php foreach ($categories as $category): ?><option value="<?= (int) $category['id'] ?>"><?= e($category['name']) ?></option><?php endforeach; ?></select></label><label>Summary<textarea name="excerpt" rows="2" required></textarea></label><label>Article text<textarea name="body" rows="8" required></textarea></label><label>Featured image<input type="file" name="featured_image" accept="image/jpeg,image/png,image/webp"></label><label>Status<select name="status"><option value="draft">Save draft</option><option value="published">Publish now</option></select></label></div><button class="button" type="submit">Save article</button></form><div class="admin-list"><?php foreach ($posts as $item): ?><article><div><strong><?= e($item['title']) ?></strong><p><?= e($item['category_name'] ?? 'Uncategorized') ?> · <?= e(ucfirst($item['status'])) ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="post_delete"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="ai"><div class="admin-section-heading"><div><p class="eyebrow">DAPHINE AI</p><h2>Digital twin assistant</h2></div></div><div class="admin-stats"><article class="admin-stat"><span>Total requests</span><strong><?= (int) $aiUsage['total'] ?></strong></article><article class="admin-stat"><span>Successful answers</span><strong><?= (int) $aiUsage['successful'] ?></strong></article><article class="admin-stat"><span>Recorded tokens</span><strong><?= (int) $aiUsage['tokens'] ?></strong></article></div><p class="muted">Model: <?= e(getenv('OPENAI_MODEL') ?: 'gpt-4o-mini') ?> · Output limit: <?= e(getenv('OPENAI_MAX_OUTPUT_TOKENS') ?: '400') ?> tokens · API key: <?= e($aiApiKeySource) ?>.</p><form class="admin-form admin-panel" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="ai_settings_save"><label>OpenAI API key<input name="ai_api_key" type="password" maxlength="512" autocomplete="new-password" placeholder="<?= $aiApiKeyConfigured ? 'Saved securely — enter a new key to replace it' : 'Paste your OpenAI API key here' ?>"><small class="muted">The key is encrypted before it is stored and is never displayed again. Configure APP_ENCRYPTION_KEY on the server before saving it. A server OPENAI_API_KEY overrides this saved key.</small></label><?php if ($savedAiApiKey !== ''): ?><label class="inline-check"><input type="checkbox" name="remove_ai_api_key" value="1"> Remove saved API key</label><?php endif; ?><label class="inline-check"><input type="checkbox" name="ai_enabled" value="1" <?= $aiEnabled ? 'checked' : '' ?>> Enable public Daphine AI (requires a configured API key)</label><label>Additional verified professional knowledge<textarea name="ai_knowledge" rows="8" maxlength="20000" placeholder="Add verified details not covered by the profile, projects, education, experience, skills, or published articles."><?= e($aiKnowledge) ?></textarea><small class="muted">Only add accurate information. Visitor messages are sent to OpenAI but are not stored by this site.</small></label><button class="button" type="submit">Save AI settings</button></form></section>
    <section class="admin-section" id="timeline"><div class="admin-section-heading"><div><p class="eyebrow">PROFESSIONAL JOURNEY</p><h2>Timeline entries</h2></div></div><form class="admin-form admin-panel" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="timeline_save"><div class="admin-fields"><label>Year or period<input name="period" maxlength="80" placeholder="e.g. 2022 – Present" required></label><label>Organization or project<input name="title" maxlength="190" required></label><label>Role<input name="role" maxlength="190"></label><label>Technologies<input name="technologies" maxlength="500" placeholder="PHP, MySQL, JavaScript"></label><label>Description<textarea name="description" rows="3" required></textarea></label><label>Display order<input name="sort_order" type="number" value="0"></label></div><button class="button" type="submit">Add journey entry</button></form><div class="admin-list"><?php foreach ($timelineEvents as $event): ?><article><form class="admin-form admin-fields" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="timeline_save"><input type="hidden" name="id" value="<?= (int) $event['id'] ?>"><label>Year or period<input name="period" value="<?= e($event['period']) ?>" required></label><label>Organization or project<input name="title" value="<?= e($event['title']) ?>" required></label><label>Role<input name="role" value="<?= e($event['role']) ?>"></label><label>Technologies<input name="technologies" value="<?= e($event['technologies']) ?>"></label><label>Description<textarea name="description" rows="2" required><?= e($event['description']) ?></textarea></label><label>Display order<input name="sort_order" type="number" value="<?= (int) $event['sort_order'] ?>"></label><button class="small-action" type="submit">Save changes</button></form><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="timeline_delete"><input type="hidden" name="id" value="<?= (int) $event['id'] ?>"><button class="danger-button" type="submit">Remove</button></form></article><?php endforeach; ?><?php if (!$timelineEvents): ?><p class="muted admin-panel">No journey entries yet. Add verified experience, education, achievements, or project milestones here.</p><?php endif; ?></div></section>
    <section class="admin-section" id="interests"><div class="admin-section-heading"><div><p class="eyebrow">CURRENTLY EXPLORING</p><h2>Innovation radar</h2></div></div><form class="admin-form admin-panel inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="interest_save"><label>Technology or interest<input name="name" maxlength="120" required></label><label>Description<input name="description" maxlength="500" required></label><label>Icon / symbol<input name="icon" maxlength="40" value="✦"></label><label>Display order<input name="sort_order" type="number" value="0"></label><button class="button" type="submit">Add or update</button></form><div class="admin-list"><?php foreach ($interests as $interest): ?><article><form class="admin-form inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="interest_save"><input type="hidden" name="id" value="<?= (int) $interest['id'] ?>"><label>Technology or interest<input name="name" value="<?= e($interest['name']) ?>" required></label><label>Description<input name="description" value="<?= e($interest['description']) ?>" required></label><label>Icon<input name="icon" value="<?= e($interest['icon']) ?>"></label><label>Display order<input name="sort_order" type="number" value="<?= (int) $interest['sort_order'] ?>"></label><button class="small-action" type="submit">Save changes</button></form><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="interest_delete"><input type="hidden" name="id" value="<?= (int) $interest['id'] ?>"><button class="danger-button" type="submit">Remove</button></form></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="terminal-commands"><div class="admin-section-heading"><div><p class="eyebrow">EXPLORE MY TERMINAL</p><h2>Terminal commands</h2></div></div><p class="muted">Built-in commands read live portfolio information and cannot be removed. Add custom commands with a plain-text response.</p><form class="admin-form admin-panel inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="terminal_command_save"><label>Command<input name="command" pattern="[a-z][a-z0-9_-]{0,39}" maxlength="40" placeholder="e.g. interests" required></label><label>Description<input name="description" maxlength="190" required></label><label>Custom output<input name="output" maxlength="2000" placeholder="Plain-text response"></label><button class="button" type="submit">Add command</button></form><div class="admin-list"><?php foreach ($terminalCommands as $command): $isBuiltIn = in_array($command['command'], ['help', 'about', 'skills', 'projects', 'experience', 'education', 'services', 'articles', 'contact', 'ai', 'clear'], true); ?><article><form class="admin-form inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="terminal_command_save"><input type="hidden" name="id" value="<?= (int) $command['id'] ?>"><label>Command<input name="command" value="<?= e($command['command']) ?>" <?= $isBuiltIn ? 'readonly' : '' ?> required></label><label>Description<input name="description" value="<?= e($command['description']) ?>" required></label><?php if (!$isBuiltIn): ?><label>Output<input name="output" value="<?= e($command['output']) ?>" maxlength="2000"></label><?php endif; ?><button class="small-action" type="submit">Save</button></form><?php if (!$isBuiltIn): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="terminal_command_delete"><input type="hidden" name="id" value="<?= (int) $command['id'] ?>"><button class="danger-button" type="submit">Remove</button></form><?php endif; ?></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="social"><div class="admin-section-heading"><div><p class="eyebrow">ELSEWHERE</p><h2>Social links</h2></div></div><form class="admin-form admin-panel inline-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="social_save"><label>Platform<input name="label" placeholder="LinkedIn" required></label><label>Profile URL<input type="url" name="url" placeholder="https://" required></label><button class="button" type="submit">Add link</button></form><p class="muted">Icons are selected automatically from the platform name; unsupported names use a link icon.</p><div class="admin-list"><?php foreach ($socialLinks as $link): ?><article><div><strong class="social-admin-label"><?= social_icon((string) $link['label']) ?><?= e($link['label']) ?></strong><p><?= e($link['url']) ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="social_delete"><input type="hidden" name="id" value="<?= (int) $link['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div></section>
    <section class="admin-section" id="messages"><div class="admin-section-heading"><div><p class="eyebrow">INBOX</p><h2>Contact messages</h2></div></div><div class="admin-list"><?php foreach ($messages as $message): ?><article class="message-row <?= $message['is_read'] ? '' : 'unread' ?>"><div><strong><?= e($message['subject']) ?></strong><p>From <?= e($message['name']) ?> · <a href="mailto:<?= e($message['email']) ?>"><?= e($message['email']) ?></a> · <?= e(date('M j, Y H:i', strtotime($message['created_at']))) ?></p><p><?= nl2br(e($message['message'])) ?></p></div><div class="message-actions"><?php if (!$message['is_read']): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="message_read"><input type="hidden" name="id" value="<?= (int) $message['id'] ?>"><button class="small-action" type="submit">Mark read</button></form><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="message_delete"><input type="hidden" name="id" value="<?= (int) $message['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></div></article><?php endforeach; ?><?php if (!$messages): ?><p class="muted admin-panel">No messages received yet.</p><?php endif; ?></div></section>
    <section class="admin-section" id="account"><div class="admin-section-heading"><div><p class="eyebrow">SECURITY</p><h2>Change password</h2></div></div><form class="admin-form admin-panel password-form" method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="password_change"><label>Current password<input type="password" name="current_password" required autocomplete="current-password"></label><label>New password (12+ characters)<input type="password" name="new_password" required minlength="12" autocomplete="new-password"></label><button class="button" type="submit">Update password</button></form></section>
    <section class="admin-section" id="experience">
        <div class="admin-section-heading"><div><p class="eyebrow">CAREER HISTORY</p><h2>Professional experience</h2></div></div>
        <form class="admin-form admin-panel" method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="experience_save">
            <div class="admin-fields"><label>Organization<input name="organization" required></label><label>Role<input name="role" required></label><label>Start date / year<input name="start_date"></label><label>End date / year<input name="end_date" placeholder="Present"></label><label>Details<textarea name="details" rows="3"></textarea></label></div>
            <button class="button" type="submit">Add experience</button>
        </form>
        <div class="admin-list"><?php foreach ($experience as $item): ?><article><div><strong><?= e($item['role']) ?> · <?= e($item['organization']) ?></strong><p><?= e($item['start_date']) ?> – <?= e($item['end_date'] ?: 'Present') ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="experience_delete"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div>
    </section>
    <section class="admin-section" id="education">
        <div class="admin-section-heading"><div><p class="eyebrow">EDUCATION</p><h2>Education history</h2></div></div>
        <form class="admin-form admin-panel" method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="education_save">
            <div class="admin-fields"><label>Institution<input name="institution" required></label><label>Qualification<input name="qualification" required></label><label>Start date / year<input name="start_date"></label><label>End date / year<input name="end_date"></label><label>Details<textarea name="details" rows="3"></textarea></label></div>
            <button class="button" type="submit">Add education</button>
        </form>
        <div class="admin-list"><?php foreach ($education as $item): ?><article><div><strong><?= e($item['qualification']) ?> · <?= e($item['institution']) ?></strong><p><?= e($item['start_date']) ?> – <?= e($item['end_date']) ?></p></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="education_delete"><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="danger-button" type="submit">Delete</button></form></article><?php endforeach; ?></div>
    </section>
</main><script src="../assets/js/admin.js?v=20261031-portrait" defer></script></body></html>
