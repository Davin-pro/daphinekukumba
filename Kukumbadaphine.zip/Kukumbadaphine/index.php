<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$services = $pdo->query('SELECT * FROM services ORDER BY sort_order, id LIMIT 8')->fetchAll();
$projects = $pdo->query('SELECT * FROM projects WHERE featured = 1 ORDER BY created_at DESC LIMIT 3')->fetchAll();
$skills = $pdo->query('SELECT * FROM skills ORDER BY sort_order, id LIMIT 12')->fetchAll();
$posts = $pdo->query("SELECT p.*, c.name AS category_name FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id WHERE p.status = 'published' ORDER BY p.published_at DESC LIMIT 3")->fetchAll();
$socialLinks = $pdo->query('SELECT * FROM social_links ORDER BY sort_order, id')->fetchAll();
$education = $pdo->query('SELECT * FROM education ORDER BY end_date DESC, id DESC')->fetchAll();
$experience = $pdo->query('SELECT * FROM experience ORDER BY end_date DESC, id DESC')->fetchAll();
$journeyEntries = $pdo->query('SELECT period, title, role, description, technologies, sort_order FROM timeline_events ORDER BY sort_order, id DESC')->fetchAll();
$interests = $pdo->query('SELECT name, description, icon FROM innovation_interests ORDER BY sort_order, id')->fetchAll();
$terminalCommands = $pdo->query('SELECT command, description, output FROM terminal_commands ORDER BY id')->fetchAll();
$terminalProjects = $pdo->query('SELECT title, description, technologies FROM projects ORDER BY featured DESC, created_at DESC LIMIT 20')->fetchAll();
$terminalArticles = $pdo->query("SELECT title, excerpt FROM blog_posts WHERE status = 'published' ORDER BY published_at DESC LIMIT 10")->fetchAll();
$terminalData = [
    'profile' => [
        'name' => $profile['name'] ?? '',
        'title' => $profile['title'] ?? '',
        'introduction' => $profile['hero_intro'] ?? '',
        'biography' => trim(($profile['biography'] ?? '') . "\n" . ($profile['about_more'] ?? '')),
        'location' => $profile['location'] ?? '',
        'email' => $profile['email'] ?? '',
        'phone' => $profile['phone'] ?? '',
    ],
    'commands' => $terminalCommands,
    'skills' => array_column($skills, 'name'),
    'projects' => $terminalProjects,
    'experience' => $experience,
    'education' => $education,
    'services' => $services,
    'articles' => $terminalArticles,
];
$timeline = [];
foreach ($journeyEntries as $entry) {
    $timeline[] = $entry;
}
foreach ($experience as $entry) {
    $timeline[] = [
        'period' => trim(($entry['start_date'] ?? '') . (($entry['start_date'] ?? '') && ($entry['end_date'] ?? '') ? ' – ' : '') . ($entry['end_date'] ?? '')) ?: 'Period not specified',
        'title' => $entry['organization'],
        'role' => $entry['role'],
        'description' => $entry['details'],
        'technologies' => '',
    ];
}
foreach ($education as $entry) {
    $timeline[] = [
        'period' => trim(($entry['start_date'] ?? '') . (($entry['start_date'] ?? '') && ($entry['end_date'] ?? '') ? ' – ' : '') . ($entry['end_date'] ?? '')) ?: 'Period not specified',
        'title' => $entry['institution'],
        'role' => $entry['qualification'],
        'description' => $entry['details'],
        'technologies' => '',
    ];
}
foreach ($terminalProjects as $entry) {
    $timeline[] = [
        'period' => 'Project',
        'title' => $entry['title'],
        'role' => $entry['technologies'],
        'description' => $entry['description'],
        'technologies' => $entry['technologies'],
    ];
}
$heroImage = $profile['hero_image'] ?: 'assets/images/canadian-rockies.jpg';
$publicBasePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$heroImageUrl = $publicBasePath . '/' . ltrim($heroImage, '/');
$heroPositionX = $profile['hero_position_x'] ?? '50%';
$heroPositionY = $profile['hero_position_y'] ?? '50%';
$portraitPositionX = $profile['portrait_position_x'] ?? '50%';
$portraitPositionY = $profile['portrait_position_y'] ?? '50%';
$portraitFit = $profile['portrait_fit'] ?? 'contain';
$portraitUrl = !empty($profile['portrait'])
    ? $publicBasePath . '/' . ltrim($profile['portrait'], '/')
    : '';
$pageTitle = ($profile['name'] ?? 'Kukumba Daphine') . ' | ' . ($profile['title'] ?? 'Computer Engineer');
$activePage = 'home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero" id="home" style="--hero-image: url('<?= e($heroImageUrl) ?>'); --hero-position: <?= e($heroPositionX) ?> <?= e($heroPositionY) ?>;">
    <div class="hero-grid">
        <div class="hero-copy reveal">
            <p class="eyebrow"><span class="eyebrow-line"></span> HELLO, I'M</p>
            <?php $nameWords = preg_split('/\s+/u', trim($profile['name'] ?? 'Kukumba Daphine'), -1, PREG_SPLIT_NO_EMPTY); ?>
            <h1 aria-label="<?= e($profile['name'] ?? 'Kukumba Daphine') ?>"><?php $characterIndex = 0; foreach ($nameWords as $wordIndex => $word): ?><span class="name-word" aria-hidden="true"><?php foreach (preg_split('//u', $word, -1, PREG_SPLIT_NO_EMPTY) as $character): ?><span class="name-character" style="--character-index: <?= min($characterIndex, 18) ?>"><?= e($character) ?></span><?php $characterIndex++; endforeach; ?></span><?= $wordIndex < count($nameWords) - 1 ? ' ' : '' ?><?php endforeach; ?><span class="name-period" aria-hidden="true">.</span></h1>
            <h2><?= e($profile['hero_title'] ?? 'Computer Engineer & Full-Stack Developer') ?></h2>
            <p class="hero-description"><?= e($profile['hero_intro'] ?? 'I build innovative digital solutions, develop powerful web applications and transform ideas into practical technology solutions.') ?></p>
            <div class="hero-actions"><a class="button" href="projects.php">View My Work <span aria-hidden="true">↗</span></a><a class="button button-outline" href="contact.php">Contact Me</a></div>
            <div class="social-row">
                <?php foreach ($socialLinks as $link): ?><a href="<?= e($link['url']) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e($link['label']) ?>"><span class="social-icon-wrap"><?= social_icon((string) $link['label']) ?></span><span><?= e($link['label']) ?></span></a><?php endforeach; ?>
                <?php if (!$socialLinks): ?><span class="muted">Connect with me</span><?php endif; ?>
            </div>
        </div>
        <div class="hero-portrait reveal" style="--portrait-position: <?= e($portraitPositionX) ?> <?= e($portraitPositionY) ?>; --portrait-fit: <?= e($portraitFit) ?>;">
            <?php if ($portraitUrl !== ''): ?><img src="<?= e($portraitUrl) ?>" alt="Portrait of <?= e($profile['name'] ?? 'Kukumba Daphine') ?>"><?php else: ?>
                <div class="portrait-placeholder"><span class="placeholder-initials">KD</span><span>Profile image<br>coming soon</span></div>
            <?php endif; ?>
            <div class="portrait-caption"><span class="status-dot"></span> Available for opportunities</div>
        </div>
    </div>
    <a class="scroll-cue" href="#about"><span></span> Scroll to explore</a>
</section>
<section class="section about-section" id="about">
    <div class="section-heading reveal"><p class="eyebrow">ABOUT ME</p><h2><?= e($profile['about_heading'] ?? 'Building Technology Solutions That Make an Impact.') ?></h2></div>
    <div class="about-grid">
        <div class="about-copy reveal"><p><?= nl2br(e($profile['biography'] ?? 'I am a technology professional with experience in software development, information technology, networking, systems administration, graphics design, digital marketing and ICT education.')) ?></p><p><?= nl2br(e($profile['about_more'] ?? 'I specialize in developing practical technology solutions, designing digital experiences, managing IT infrastructure and helping organizations leverage technology to improve their operations.')) ?></p><a class="text-link" href="contact.php">Let's work together <span>↗</span></a><?php if ($profile['cv_file'] ?? false): ?><a class="text-link cv-link" href="<?= e($profile['cv_file']) ?>" target="_blank" rel="noopener noreferrer">Download CV <span>↓</span></a><?php endif; ?></div>
        <div class="stats-grid reveal">
            <article class="stat-card"><strong><?= e($profile['experience_stat'] ?? 'IT') ?></strong><span>Experience</span></article>
            <article class="stat-card"><strong><?= e($profile['projects_stat'] ?? 'Web') ?></strong><span>Projects completed</span></article>
            <article class="stat-card"><strong><?= e($profile['skills_stat'] ?? 'Full-stack') ?></strong><span>Technical skills</span></article>
            <article class="stat-card"><strong><?= e($profile['roles_stat'] ?? 'Multi-disciplinary') ?></strong><span>Professional roles</span></article>
        </div>
    </div>
    <div class="contact-strip reveal">
        <div><span class="detail-label">LOCATION</span><strong><?= e($profile['location'] ?? 'Namagoma, Wakiso, Uganda') ?></strong></div>
        <div><span class="detail-label">EMAIL</span><?php if ($profile['email'] ?? ''): ?><a href="mailto:<?= e($profile['email']) ?>"><?= e($profile['email']) ?></a><?php else: ?><strong>Add email in admin</strong><?php endif; ?></div>
        <div><span class="detail-label">PHONE</span><?php if ($profile['phone'] ?? ''): ?><a href="tel:<?= e($profile['phone']) ?>"><?= e($profile['phone']) ?></a><?php else: ?><strong>Add phone in admin</strong><?php endif; ?></div>
        <div><span class="detail-label">LANGUAGES</span><strong><?= e($profile['languages'] ?? 'English') ?></strong></div>
    </div>
    <?php if ($experience || $education): ?><div class="resume-grid">
        <?php if ($experience): ?><div><p class="eyebrow">PROFESSIONAL EXPERIENCE</p><?php foreach ($experience as $item): ?><article class="resume-item"><h3><?= e($item['role']) ?></h3><span><?= e($item['organization']) ?><?= $item['start_date'] || $item['end_date'] ? ' · ' . e($item['start_date']) . ' – ' . e($item['end_date'] ?: 'Present') : '' ?></span><p><?= nl2br(e($item['details'])) ?></p></article><?php endforeach; ?></div><?php endif; ?>
        <?php if ($education): ?><div><p class="eyebrow">EDUCATION</p><?php foreach ($education as $item): ?><article class="resume-item"><h3><?= e($item['qualification']) ?></h3><span><?= e($item['institution']) ?><?= $item['start_date'] || $item['end_date'] ? ' · ' . e($item['start_date']) . ' – ' . e($item['end_date'] ?: 'Present') : '' ?></span><p><?= nl2br(e($item['details'])) ?></p></article><?php endforeach; ?></div><?php endif; ?>
    </div><?php endif; ?>
</section>
<script type="application/json" id="terminalData"><?= json_encode($terminalData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<section class="section section-muted journey-section" id="journey">
    <div class="section-heading reveal"><p class="eyebrow">THE JOURNEY</p><h2>Professional journey</h2></div>
    <?php if ($timeline): ?><div class="journey-timeline"><?php foreach ($timeline as $entry): ?><article class="journey-card reveal"><span class="journey-marker" aria-hidden="true"></span><p class="eyebrow"><?= e($entry['period']) ?></p><h3><?= e($entry['title']) ?></h3><?php if ($entry['role']): ?><p class="journey-role"><?= e($entry['role']) ?></p><?php endif; ?><p><?= nl2br(e($entry['description'])) ?></p><?php if ($entry['technologies']): ?><span class="journey-tech"><?= e($entry['technologies']) ?></span><?php endif; ?></article><?php endforeach; ?></div>
    <?php else: ?><p class="empty-state">Verified experience, education, and project milestones will appear here as they are added.</p><?php endif; ?>
</section>
<section class="section innovation-section" id="innovation">
    <div class="section-heading section-heading-row reveal"><div><p class="eyebrow">CURRENTLY EXPLORING</p><h2>Innovation radar</h2></div><p>Technologies and areas of interest shaping what comes next.</p></div>
    <div class="innovation-grid"><?php foreach ($interests as $interest): ?><article class="innovation-card reveal"><span class="innovation-icon" aria-hidden="true"><?= e($interest['icon']) ?></span><h3><?= e($interest['name']) ?></h3><p><?= e($interest['description']) ?></p></article><?php endforeach; ?><?php if (!$interests): ?><p class="empty-state">Areas of interest will be added soon.</p><?php endif; ?></div>
</section>
<section class="section section-muted terminal-section" id="terminal">
    <div class="section-heading section-heading-row reveal"><div><p class="eyebrow">INTERACTIVE DEVELOPER TERMINAL</p><h2>Explore my terminal</h2></div><p>Try a command to explore my portfolio. Use ↑ / ↓ for command history.</p></div>
    <div class="developer-terminal reveal" id="developerTerminal">
        <div class="terminal-chrome"><span class="terminal-lights" aria-hidden="true"><i></i><i></i><i></i></span><span>visitor@daphine — portfolio</span><button type="button" class="terminal-clear" data-terminal-command="clear">Clear</button></div>
        <div class="terminal-output" id="terminalOutput" role="log" aria-live="polite" aria-relevant="additions text"><div class="terminal-line terminal-system">Interactive portfolio terminal. Type <b>help</b> to see available commands.</div></div>
        <form class="terminal-form" id="terminalForm"><label for="terminalInput" aria-hidden="true">visitor@daphine:~$</label><input id="terminalInput" name="command" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Enter a terminal command" aria-describedby="terminalHint"><span class="terminal-cursor" aria-hidden="true"></span></form>
        <p class="sr-only" id="terminalHint">Type help to list commands. Use the up and down arrow keys to browse command history.</p>
        <div class="terminal-shortcuts" aria-label="Suggested terminal commands"><?php foreach (['about', 'skills', 'projects', 'experience', 'education', 'services', 'articles', 'contact', 'ai'] as $command): ?><button type="button" data-terminal-command="<?= e($command) ?>"><?= e($command) ?></button><?php endforeach; ?></div>
    </div>
</section>
<section class="section section-muted" id="services">
    <div class="section-heading section-heading-row reveal"><div><p class="eyebrow">WHAT I DO</p><h2>Services & expertise</h2></div><p>Practical technology, thoughtfully delivered to help people and organizations move forward.</p></div>
    <div class="services-grid">
        <?php foreach ($services as $index => $service): ?><article class="service-card reveal"><span class="service-number"><?= sprintf('%02d', $index + 1) ?></span><div class="service-icon"><?= e($service['icon'] ?: '*') ?></div><h3><?= e($service['name']) ?></h3><p><?= e($service['description']) ?></p></article><?php endforeach; ?>
        <?php if (!$services): ?><p class="empty-state">Services will appear here soon.</p><?php endif; ?>
    </div>
    <?php if ($skills): ?><div class="skills-row"><?php foreach ($skills as $skill): ?><span><?= e($skill['name']) ?></span><?php endforeach; ?></div><?php endif; ?>
</section>
<section class="section" id="projects">
    <div class="section-heading section-heading-row reveal"><div><p class="eyebrow">SELECTED WORK</p><h2>Featured projects</h2></div><a class="text-link" href="projects.php">Explore all projects <span>↗</span></a></div>
    <div class="project-grid">
        <?php foreach ($projects as $project): ?><a class="project-card reveal" href="project-details.php?id=<?= (int) $project['id'] ?>">
            <div class="project-image"><?php if ($project['image']): ?><img src="<?= e($project['image']) ?>" alt="<?= e($project['title']) ?>"><?php else: ?><div class="project-placeholder"><span>PROJECT<br>PREVIEW</span></div><?php endif; ?><span class="project-arrow">↗</span></div>
            <div class="project-meta"><span><?= e($project['category'] ?: 'Selected work') ?></span><span><?= e($project['technologies']) ?></span></div><h3><?= e($project['title']) ?></h3><p><?= e($project['description']) ?></p>
        </a><?php endforeach; ?>
        <?php if (!$projects): ?><p class="empty-state">Project previews will appear here once they are added from the dashboard.</p><?php endif; ?>
    </div>
</section>
<section class="section section-muted" id="journal">
    <div class="section-heading section-heading-row reveal"><div><p class="eyebrow">LATEST INSIGHTS</p><h2>From the journal</h2></div><a class="text-link" href="blog.php">View all articles <span>↗</span></a></div>
    <div class="journal-grid"><?php foreach ($posts as $post): ?><a class="journal-card reveal" href="blog-details.php?slug=<?= urlencode($post['slug']) ?>">
        <?php if ($post['featured_image']): ?><img src="<?= e($post['featured_image']) ?>" alt=""><?php else: ?><div class="journal-placeholder">KD<span> JOURNAL</span></div><?php endif; ?>
        <div class="journal-content"><span class="detail-label"><?= e($post['category_name'] ?? 'ARTICLE') ?> · <?= e($post['published_at'] ? date('M j, Y', strtotime($post['published_at'])) : '') ?></span><h3><?= e($post['title']) ?></h3><p><?= e($post['excerpt']) ?></p><span class="text-link">Read article ↗</span></div>
    </a><?php endforeach; ?><?php if (!$posts): ?><p class="empty-state">Articles and insights will appear here.</p><?php endif; ?></div>
</section>
<section class="section cta-section"><div class="cta-card reveal"><div><p class="eyebrow">HAVE A PROJECT IN MIND?</p><h2>Let's build something<br>that matters.</h2></div><a class="button" href="contact.php">Start a conversation <span>↗</span></a></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
