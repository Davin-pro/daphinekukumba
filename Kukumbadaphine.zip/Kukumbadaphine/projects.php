<?php
require_once __DIR__ . '/includes/functions.php';
$profile = profile($pdo);
$projects = $pdo->query('SELECT * FROM projects ORDER BY featured DESC, created_at DESC')->fetchAll();
$pageTitle = 'Projects | ' . ($profile['name'] ?? 'Kukumba Daphine');
$activePage = 'projects';
require __DIR__ . '/includes/header.php';
?>
<section class="page-hero"><p class="eyebrow">PORTFOLIO</p><h1>Selected projects<span>.</span></h1><p>A collection of work, experiments and practical solutions.</p></section>
<section class="section"><div class="project-grid"><?php foreach ($projects as $project): ?><a class="project-card reveal" href="project-details.php?id=<?= (int) $project['id'] ?>"><div class="project-image"><?php if ($project['image']): ?><img src="<?= e($project['image']) ?>" alt="<?= e($project['title']) ?>"><?php else: ?><div class="project-placeholder"><span>PROJECT<br>PREVIEW</span></div><?php endif; ?><span class="project-arrow">↗</span></div><div class="project-meta"><span><?= e($project['category']) ?></span><span><?= e($project['technologies']) ?></span></div><h3><?= e($project['title']) ?></h3><p><?= e($project['description']) ?></p></a><?php endforeach; ?><?php if (!$projects): ?><p class="empty-state">Projects will be published here soon.</p><?php endif; ?></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
